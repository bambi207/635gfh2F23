<?php
/**
 * Data class.
 *
 * @package fwdevp
 * @since fwdevp 1.0
 */

class FWDEVPData{

	const DEFAULT_SKINS_NR = 8;
	public $settings_ar;
	public $ads_ar;
	public $videoStartBehaviour;
	public $replaceDF;
	public $replaceDFSkin;
	public $keepCookies;

	
    // Initialize.
    public function init(){
		$cur_data = get_option("fwdevp_data");

		// Uncomment this to reset presets!
		//$this->reset_presets();

	    if (!$cur_data){
	    	$this->init_settings();
	    	$this->set_data();
	    }
		
		$this->set_updates();
		$this->get_data();
    }
	

	// Reset presets.
	private function reset_presets(){
		$this->get_data();
		$this->init_settings();
	    $this->set_data();
	}
	

	// Reset advertisement.
	private function reset_ads(){
	    $this->ads_ar = array();
	}
	

	// Set updates when ready.
	private function set_updates(){
		$this->get_data();

		$this->videoStartBehaviour = get_option("fwdevp_data")->videoStartBehaviour;
		if(!isSet($this->videoStartBehaviour))  $this->videoStartBehaviour = "pause";

		$this->replaceDF = get_option("fwdevp_data")->replaceDF;
		if(!isSet($this->replaceDF))  $this->replaceDF = "no";

		$this->replaceDFSkin = get_option("fwdevp_data")->replaceDFSkin;
		if(!isSet($this->replaceDFSkin))  $this->replaceDFSkin = "skin_minimal_dark";
		
		$this->keepCookies = get_option("fwdevp_data")->keepCookies;
		if(!isSet($this->keepCookies))  $this->keepCookies = "no";

   		foreach ($this->settings_ar as &$preset){

   			if(!array_key_exists("showYoutubeRelAndInfo", $preset)){
	    		$preset["showYoutubeRelAndInfo"] = "no";
			}

   			if(!array_key_exists("showAudioTracksButton", $preset)){
	    		$preset["showAudioTracksButton"] = "yes";
			}

   			if(!array_key_exists("show360DegreeVideoVrButton", $preset)){
	    		$preset["show360DegreeVideoVrButton"] =  "no";
			}

   			if(!array_key_exists("closeLightBoxWhenPlayComplete", $preset)){
	    		$preset["closeLightBoxWhenPlayComplete"] =  "no";
			}

   			if(!array_key_exists("useWithoutVideoScreen", $preset)){
	    		$preset["useWithoutVideoScreen"] =  "no";
			}

   			if(!array_key_exists("showScrubberWhenControllerIsHidden", $preset)){
	    		$preset["showScrubberWhenControllerIsHidden"] =  "yes";
			}
   			
   			if(!array_key_exists("showChromecastButton", $preset)){
	    		$preset["showChromecastButton"] =  "no";
			}

   			if(!array_key_exists("playsinline", $preset)){
	    		$preset["playsinline"] =  "yes";
			}
   			if(!array_key_exists("thumbnails_preview_width", $preset)){
	    		$preset["thumbnails_preview_width"] =  196;
			}
			if(!array_key_exists("thumbnails_preview_height", $preset)){
	    		$preset["thumbnails_preview_height"] =  110;
			}
			if(!array_key_exists("thumbnails_preview_background_color", $preset)){
	    		$preset["thumbnails_preview_background_color"] =  "#000";
			}
			if(!array_key_exists("thumbnails_preview_border_color", $preset)){
	    		$preset["thumbnails_preview_border_color"] =  "#666";
			}
			if(!array_key_exists("thumbnails_preview_label_background_color", $preset)){
	    		$preset["thumbnails_preview_label_background_color"] =  "#666";
			}
			if(!array_key_exists("thumbnails_preview_label_font_color", $preset)){
	    		$preset["thumbnails_preview_label_font_color"] =  "#FFF";
			}

   			if(!array_key_exists("use_resume_on_play", $preset)){
	    		$preset["use_resume_on_play"] =  "no";
			}
   			if(!array_key_exists("stickyOnScroll", $preset)){
	    		$preset["stickyOnScroll"] =  "no";
			}
			if(!array_key_exists("stickyOnScrollShowOpener", $preset)){
	    		$preset["stickyOnScrollShowOpener"] =  "yes";
			}
			if(!array_key_exists("stickyOnScrollWidth", $preset)){
	    		$preset["stickyOnScrollWidth"] =  700;
			}
			if(!array_key_exists("stickyOnScrollHeight", $preset)){
	    		$preset["stickyOnScrollHeight"] =  394;
			}
			
			if(!array_key_exists("showMainScrubberToolTipLabel", $preset)){
	    		$preset["showMainScrubberToolTipLabel"] =  "yes";
			}
			
			if(!array_key_exists("scrubbersToolTipLabelBackgroundColor", $preset)){
	    		$preset["scrubbersToolTipLabelBackgroundColor"] =  "#FFFFFF";
			}
			
			if(!array_key_exists("scrubbersToolTipLabelFontColor", $preset)){
	    		$preset["scrubbersToolTipLabelFontColor"] =  "#000000";
			}

			// update new or existing fields
			if(!array_key_exists("lightBoxBackgroundOpacity", $preset)){
	    		$preset["lightBoxBackgroundOpacity"] =  .6;
			}
			
			if(!array_key_exists("useFontAwesomeIcons", $preset)){
	    		$preset["useFontAwesomeIcons"] =  "no";
			}
			
			if(!array_key_exists("lightBoxBackgroundColor", $preset)){
	    		$preset["lightBoxBackgroundColor"] =  "#000000";
			}
			
			if(!array_key_exists("googleAnalyticsTrackingCode", $preset)){
	    		$preset["googleAnalyticsTrackingCode"] =  "";
			}
			
			if(!array_key_exists("showRewindButton", $preset)){
	    		$preset["showRewindButton"] =  "yes";
			}
					
			if(!array_key_exists("showOpener", $preset)){
	    		$preset["showOpener"] =  "yes";
			}
			if(!array_key_exists("showOpenerPlayPauseButton", $preset)){
	    		$preset["showOpenerPlayPauseButton"] =  "yes";
			}
			if(!array_key_exists("verticalPosition", $preset)){
	    		$preset["verticalPosition"] =  "bottom";
			}
			if(!array_key_exists("horizontalPosition", $preset)){
	    		$preset["horizontalPosition"] =  "center";
			}
			if(!array_key_exists("showPlayerByDefault", $preset)){
	    		$preset["showPlayerByDefault"] =  "yes";
			}
			if(!array_key_exists("animatePlayer", $preset)){
	    		$preset["animatePlayer"] =  "yes";
			}
			if(!array_key_exists("openerAlignment", $preset)){
	    		$preset["openerAlignment"] =  "right";
			}
			if(!array_key_exists("mainBackgroundImagePath", $preset)){
	    		$preset["mainBackgroundImagePath"] =  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png";
			}
			if(!array_key_exists("openerEqulizerOffsetTop", $preset)){
	    		$preset["openerEqulizerOffsetTop"] =  -1;
			}
			if(!array_key_exists("openerEqulizerOffsetLeft", $preset)){
	    		$preset["openerEqulizerOffsetLeft"] =  3;
			}
			if(!array_key_exists("offsetX", $preset)){
	    		$preset["offsetX"] =  0;
			}
			if(!array_key_exists("offsetY", $preset)){
	    		$preset["offsetY"] =  0;
			}
			
			if (!array_key_exists("showDefaultControllerForVimeo", $preset)){
	    		$preset["showDefaultControllerForVimeo"] =  "yes";
			}
			
			if (!array_key_exists("preloaderColor1", $preset)){
	    		$preset["preloaderColor1"] =  "#FFFFFFF";
			}
			
			if (!array_key_exists("preloaderColor2", $preset)){
	    		$preset["preloaderColor2"] =  "#000000";
			}
			
			if (!array_key_exists("show_popup_ads_close_button", $preset)){
				$preset["show_popup_ads_close_button"] = "yes";
			}
			
			if (!array_key_exists("showErrorInfo", $preset)){
				$preset["showErrorInfo"] = "yes";
			}
			
			if (!array_key_exists("playVideoOnlyWhenLoggedIn", $preset)){
				$preset["playVideoOnlyWhenLoggedIn"] = "no";
			}

			if (!array_key_exists("autoPlayText", $preset)){
				$preset["autoPlayText"] = "Click To Unmute";
			}

			if (!array_key_exists("goFullScreenOnButtonPlay", $preset)){
				$preset["goFullScreenOnButtonPlay"] = "no";
			}
			
			if (!array_key_exists("loggedInMessage", $preset)){
				$preset["loggedInMessage"] = "Please loggin to view this video.";
			}	
			
			if (!array_key_exists("executeCuepointsOnlyOnce", $preset)){
				$preset["executeCuepointsOnlyOnce"] = "no";
			}
			
			if (!array_key_exists("privateVideoPassword", $preset)){
				$preset["privateVideoPassword"] = "Melinda";
			}
			
			if (!array_key_exists("encryptVideosPath", $preset)){
				$preset["encryptVideosPath"] = "no";
			}
			
			if (!array_key_exists("disableDoubleClickFullscreen", $preset)){
				$preset["disableDoubleClickFullscreen"] = "no";
			}
			
			if (!array_key_exists("audioVisualizerCircleColor", $preset)){
				$preset["audioVisualizerCircleColor"] = "#FFFFFF";
			}
			
			if (!array_key_exists("audioVisualizerLinesColor", $preset)){
				$preset["audioVisualizerLinesColor"] = "#000000";
			}
			
			
			if (!array_key_exists("use_chromeless", $preset)){
				$preset["use_chromeless"] = "no";
			}
			
			if (!array_key_exists("fill_entire_video_screen", $preset)){
				$preset["fill_entire_video_screen"] = "no";
			}
			
			if (!array_key_exists("defaultPlaybackRate", $preset)){
				$preset["defaultPlaybackRate"] = 1;
			}
			
			if (!array_key_exists("greenScreenTolerance", $preset)){
				$preset["greenScreenTolerance"] = 200;
			}
			
			if (!array_key_exists("showPreloader", $preset)){
				$preset["showPreloader"] = "yes";
			}
			
			if (!array_key_exists("showPlaybackRateButton", $preset)){
				$preset["showPlaybackRateButton"] = "no";
			}
			
			if (!array_key_exists("fillEntireScreenWithPoster", $preset)){
				$preset["fillEntireScreenWithPoster"] = "no";
			}
			
			if (!array_key_exists("use_HEX_colors_for_skin", $preset)){
				$preset["use_HEX_colors_for_skin"] = "no";
			}	
			if (!array_key_exists("normal_HEX_buttons_color", $preset)){
				$preset["normal_HEX_buttons_color"] = "no";
			}	
			
			if (!array_key_exists("selected_HEX_buttons_color", $preset)){
				$preset["selected_HEX_buttons_color"] = "no";
			}	
						
			if (!array_key_exists("show_controller", $preset)){
				$preset["show_controller"] = "yes";
			}

			if (!array_key_exists("initializeOnlyWhenVisible", $preset)){
				$preset["initializeOnlyWhenVisible"] = "no";
			}
			
			if (!array_key_exists("openDownloadLinkOnMobile", $preset)){
				$preset["openDownloadLinkOnMobile"] = "no";
			}
			
			if (!array_key_exists("aopwTitle", $preset)){
				$preset["aopwTitle"] = "Advertisement";
			}
			
			if (!array_key_exists("aopwWidth", $preset)){
				$preset["aopwWidth"] = 400;
			}
			
			if (!array_key_exists("aopwHeight", $preset)){
				$preset["aopwHeight"] = 240;
			}
			
			if (!array_key_exists("aopwBorderSize", $preset)){
				$preset["aopwBorderSize"] = 6;
			}
			
			if (!array_key_exists("show_share_button", $preset)){
				$preset["show_share_button"] = "yes";
			}
			
			if (!array_key_exists("start_at_subtitle", $preset)){
				$preset["start_at_subtitle"] = 1;
			}
			
			if (!array_key_exists("show_subtitle_button", $preset)){
				$preset["show_subtitle_button"] = "yes";
			}
			
			if (!array_key_exists("subtitles_off_label", $preset)){
				$preset["subtitles_off_label"] = "Subtitle off";
			}
			
			if (!array_key_exists("open_new_page_at_the_end_of_the_ads", $preset)){
				$preset["open_new_page_at_the_end_of_the_ads"] = "no";
			}
			if (!array_key_exists("ads_buttons_position", $preset)){
				$preset["ads_buttons_position"] = "right";
			}
			if (!array_key_exists("ads_page_to_open_url", $preset)){
				$preset["ads_page_to_open_url"] = "http://www.webdesign-flash.ro";
			}
			if (!array_key_exists("ads_page_to_open_target", $preset)){
				$preset["ads_page_to_open_target"] = "_blank";
			}
			
			if (!array_key_exists("start_at_video_source", $preset)){
				$preset["start_at_video_source"] = 0;
			}
			
			if (!array_key_exists("show_download_button", $preset)){
				$preset["show_download_button"] = "no";
			}
		
			if (!array_key_exists("skip_to_video_text", $preset)){
				$preset["skip_to_video_text"] = "You can skip to video in: ";
			}
			if (!array_key_exists("skip_to_video_button_text", $preset)){
				$preset["skip_to_video_button_text"] = "Skip Ad";
			}
			if (!array_key_exists("time_to_hold_ads", $preset)){
				$preset["time_to_hold_ads"] = 4;
			}
			switch ($preset["skin_path"]){
				case "minimal_skin_dark":

					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}

					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}

					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#1f1f1f";
					}

					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#1f1f1f";
					}

					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#333";
					}

					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#888888";
					}

					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#FFF";
					}

					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#444";
					}
				
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#777777";
					}
					
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#FFFFFF";
					}
					
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#FFFFFF";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#444444";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#FFFFFF";
					}
					break;
				case "modern_skin_dark":

					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#1f1f1f";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#1f1f1f";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#333";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#6a6a6a";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#333";
					}
				
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#777777";
					}
					
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#FFFFFF";
					}
					
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#FFFFFF";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#444444";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#FFFFFF";
					}
					break;
				case "classic_skin_dark":

					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#1b1b1b";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#1b1b1b";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#333";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#bdbdbd";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#333";
					}
				
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#bdbdbd";
					}
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#FFFFFF";
					}
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#FFFFFF";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#444444";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#FFFFFF";
					}
					break;
				case "metal_skin_dark":

					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#1b1b1b";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#1b1b1b";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#333";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#888888";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#333";
					}
				
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#999999";
					}
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#FFFFFF";
					}
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#FFFFFF";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#666666";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#FFFFFF";
					}
					break;
				case "minimal_skin_white":
					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#ebebeb";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#ebebeb";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#CCC";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#888888";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#000";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#BBB";
					}
				
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#000000";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#888888";
					}
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#FFFFFF";
					}
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#000000";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#AAAAAA";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#000000";
					}
					break;
				case "modern_skin_white":

					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#e3e3e3";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#e3e3e3";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#CCC";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#777";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#000";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#BBB";
					}
					
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#000000";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#6a6a6a";
					}
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#000000";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#BBBBBB";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#000000";
					}
					break;
				case "classic_skin_white":

					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#ebebeb";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#ebebeb";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#CCC";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#666666";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#000";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#AAA";
					}
					
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#000000";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#FFFFFF";
					}
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#494949";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#BBBBBB";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#494949";
					}
					break;
				case "metal_skin_white":
					if (!array_key_exists("contextMenuType", $preset)){
						$preset["contextMenuType"] = "default";
					}
					if (!array_key_exists("showScriptDeveloper", $preset)){
						$preset["showScriptDeveloper"] = "no";
					}
					if (!array_key_exists("contextMenuBackgroundColor", $preset)){
						$preset["contextMenuBackgroundColor"] = "#dcdcdc";
					}
					if (!array_key_exists("contextMenuBorderColor", $preset)){
						$preset["contextMenuBorderColor"] = "#dcdcdc";
					}
					if (!array_key_exists("contextMenuSpacerColor", $preset)){
						$preset["contextMenuSpacerColor"] = "#CCC";
					}
					if (!array_key_exists("contextMenuItemNormalColor", $preset)){
						$preset["contextMenuItemNormalColor"] = "#666666";
					}
					if (!array_key_exists("contextMenuItemSelectedColor", $preset)){
						$preset["contextMenuItemSelectedColor"] = "#000";
					}
					if (!array_key_exists("contextMenuItemDisabledColor", $preset)){
						$preset["contextMenuItemDisabledColor"] = "#AAA";
					}
					
					if (!array_key_exists("useAToB", $preset)){
						$preset["useAToB"] = "no";
					}
					if (!array_key_exists("atbTimeBackgroundColor", $preset)){
						$preset["atbTimeBackgroundColor"] = "transparent";
					}
					if (!array_key_exists("atbTimeTextColorNormal", $preset)){
						$preset["atbTimeTextColorNormal"] = "#888888";
					}
					if (!array_key_exists("atbTimeTextColorSelected", $preset)){
						$preset["atbTimeTextColorSelected"] = "#000000";
					}
					if (!array_key_exists("atbButtonTextNormalColor", $preset)){
						$preset["atbButtonTextNormalColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonTextSelectedColor", $preset)){
						$preset["atbButtonTextSelectedColor"] = "#FFFFFF";
					}
					if (!array_key_exists("atbButtonBackgroundNormalColor", $preset)){
						$preset["atbButtonBackgroundNormalColor"] = "#888888";
					}
					if (!array_key_exists("atbButtonBackgroundSelectedColor", $preset)){
						$preset["atbButtonBackgroundSelectedColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_normal_color", $preset)){
						$preset["ads_text_normal_color"] = "#777777";
					}
					if (!array_key_exists("aopwTitleColor", $preset)){
						$preset["aopwTitleColor"] = "#000000";
					}
					if (!array_key_exists("ads_text_selected_color", $preset)){
						$preset["ads_text_selected_color"] = "#333333";
					}
					
					if (!array_key_exists("ads_border_normal_color", $preset)){
						$preset["ads_border_normal_color"] = "#AAAAAA";
					}
					
					if (!array_key_exists("ads_border_selected_color", $preset)){
						$preset["ads_border_selected_color"] = "#333333";
					}
					break;
			}
    	}

		$this->set_data();
	}
    

    // Initialize presets.
    private function init_settings() {
    	if(!empty(get_option("fwdevp_data"))){
			$this->videoStartBehaviour = get_option("fwdevp_data")->videoStartBehaviour;
			if(!isSet($this->videoStartBehaviour))  $this->videoStartBehaviour = "pause";
		}
		
		if(!empty(get_option("fwdevp_data"))){
			$this->keepCookies = get_option("fwdevp_data")->keepCookies;
			if(!isSet($this->keepCookies))  $this->keepCookies = "no";
		}
		
		if(FWDEVP_TEXT_DOMAIN == 'acora'){
			$this->settings_ar = array(
				array(
						// main settings
						"id" => 0,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "default",
						"skin_path" => "minimal_skin_dark",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "yes",
						"display_type" => "responsive",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"showDefaultControllerForVimeo" => "yes",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#FFFFFF",
						"scrubbersToolTipLabelFontColor" => "#5a5a5a",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"show_download_button" => "no",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#000000",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,
						
						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#FFFFFF",
						"atbButtonTextNormalColor" => "#888888",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#FFFFFF",
						"atbButtonBackgroundSelectedColor" => "#000000",
				
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 41,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 14,
						"space_between_buttons" => 12,
						"scrubbers_offset_width" => 2,
						"main_scrubber_offest_top" => 14,
						"time_offset_left_width" => 5,
						"time_offset_right_width" => 6,
						"volume_scrubber_width" => 80,
						"volume_scrubber_offset_right_width" => 0,
						"time_color" => "#888888",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#888888",
						"youtube_quality_button_selected_color" => "#FFFFFF",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#000000",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#FFFFFF",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#333333",
						"main_labels_color" => "#FFFFFF",
						"secondary_labels_color" => "#a1a1a1",
						"share_and_embed_text_color" => "#5a5a5a",
						"input_background_color" => "#000000",
						"input_color" => "#FFFFFF",

						// context menu
						"contextMenuType" =>'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#1f1f1f",
						"contextMenuBorderColor" => "#1f1f1f",
						"contextMenuSpacerColor" => "#333",
						"contextMenuItemNormalColor" => "#888888",
						"contextMenuItemSelectedColor" => "#FFFFFF",
						"contextMenuItemDisabledColor" => "#444"
				)
			);
		}else{
    		$this->settings_ar = array(
				array(
						// main settings
						"id" => 0,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_minimal_dark",
						"skin_path" => "minimal_skin_dark",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"display_type" => "responsive",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"showDefaultControllerForVimeo" => "yes",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#FFFFFF",
						"scrubbersToolTipLabelFontColor" => "#5a5a5a",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"show_download_button" => "no",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#000000",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,
						
						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#FFFFFF",
						"atbButtonTextNormalColor" => "#888888",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#FFFFFF",
						"atbButtonBackgroundSelectedColor" => "#000000",
				
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 41,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 7,
						"space_between_buttons" => 9,
						"scrubbers_offset_width" => 4,
						"main_scrubber_offest_top" => 14,
						"time_offset_left_width" => 5,
						"time_offset_right_width" => 3,
						"volume_scrubber_width" => 80,
						"volume_scrubber_offset_right_width" => 0,
						"time_color" => "#888888",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#888888",
						"youtube_quality_button_selected_color" => "#FFFFFF",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#000000",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#FFFFFF",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#333333",
						"main_labels_color" => "#FFFFFF",
						"secondary_labels_color" => "#a1a1a1",
						"share_and_embed_text_color" => "#5a5a5a",
						"input_background_color" => "#000000",
						"input_color" => "#FFFFFF",

						// context menu
						"contextMenuType" =>'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#1f1f1f",
						"contextMenuBorderColor" => "#1f1f1f",
						"contextMenuSpacerColor" => "#333",
						"contextMenuItemNormalColor" => "#888888",
						"contextMenuItemSelectedColor" => "#FFFFFF",
						"contextMenuItemDisabledColor" => "#444"
				),
				array(
						// main settings
						"id" => 1,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_modern_dark",
						"skin_path" => "modern_skin_dark",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#FFFFFF",
						"scrubbersToolTipLabelFontColor" => "#5a5a5a",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#000000",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,
						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",

						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#FFFFFF",
						"atbButtonTextNormalColor" => "#888888",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#FFFFFF",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 43,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 8,
						"space_between_buttons" => 12,
						"scrubbers_offset_width" => 4,
						"main_scrubber_offest_top" => 15,
						"time_offset_left_width" => 1,
						"time_offset_right_width" => -2,
						"volume_scrubber_width" => 90,
						"volume_scrubber_offset_right_width" => 2,
						"time_color" => "#888888",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#888888",
						"youtube_quality_button_selected_color" => "#FFFFFF",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#FFFFFF",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#333333",
						"main_labels_color" => "#FFFFFF",
						"secondary_labels_color" => "#a1a1a1",
						"share_and_embed_text_color" => "#5a5a5a",
						"input_background_color" => "#000000",
						"input_color" => "#FFFFFF",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#1f1f1f",
						"contextMenuBorderColor" => "#1f1f1f",
						"contextMenuSpacerColor" => "#333",
						"contextMenuItemNormalColor" => "#6a6a6a",
						"contextMenuItemSelectedColor" => "#FFFFFF",
						"contextMenuItemDisabledColor" => "#333"
				),
				array(
						// main settings
						"id" => 2,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_classic_dark",
						"skin_path" => "classic_skin_dark",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#FFFFFF",
						"scrubbersToolTipLabelFontColor" => "#5a5a5a",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#000000",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,

						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#FFFFFF",
						"atbButtonTextNormalColor" => "#888888",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#FFFFFF",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "no",
						"controller_height" => 43,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 11,
						"space_between_buttons" => 11,
						"scrubbers_offset_width" => 2,
						"main_scrubber_offest_top" => 15,
						"time_offset_left_width" => 1,
						"time_offset_right_width" => 2,
						"volume_scrubber_width" => 80,
						"volume_scrubber_offset_right_width" => 0,
						"time_color" => "#888888",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#888888",
						"youtube_quality_button_selected_color" => "#FFFFFF",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#FFFFFF",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#333333",
						"main_labels_color" => "#FFFFFF",
						"secondary_labels_color" => "#a1a1a1",
						"share_and_embed_text_color" => "#5a5a5a",
						"input_background_color" => "#000000",
						"input_color" => "#FFFFFF",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#1b1b1b",
						"contextMenuBorderColor" => "#1b1b1b",
						"contextMenuSpacerColor" => "#333",
						"contextMenuItemNormalColor" => "#bdbdbd",
						"contextMenuItemSelectedColor" => "#FFFFFF",
						"contextMenuItemDisabledColor" => "#333"
				),
				array(
						// main settings
						"id" => 3,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_metal_dark",
						"skin_path" => "metal_skin_dark",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#bbbbbb",
						"scrubbersToolTipLabelFontColor" => "#5a5a5a",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#000000",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,

						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#FFFFFF",
						"atbButtonTextNormalColor" => "#888888",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#FFFFFF",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show_controller" => "yes",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 43,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 11,
						"space_between_buttons" => 11,
						"scrubbers_offset_width" => 4,
						"main_scrubber_offest_top" => 15,
						"time_offset_left_width" => 2,
						"time_offset_right_width" => 3,
						"volume_scrubber_width" => 90,
						"volume_scrubber_offset_right_width" => 2,
						"time_color" => "#999999",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#999999",
						"youtube_quality_button_selected_color" => "#FFFFFF",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#FFFFFF",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 0,
						"border_color" => "#333333",
						"main_labels_color" => "#FFFFFF",
						"secondary_labels_color" => "#a1a1a1",
						"share_and_embed_text_color" => "#5a5a5a",
						"input_background_color" => "#000000",
						"input_color" => "#FFFFFF",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#1b1b1b",
						"contextMenuBorderColor" => "#1b1b1b",
						"contextMenuSpacerColor" => "#333",
						"contextMenuItemNormalColor" => "#888888",
						"contextMenuItemSelectedColor" => "#FFFFFF",
						"contextMenuItemDisabledColor" => "#333"
				),
				array(
						// main settings
						"id" => 4,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_minimal_white",
						"skin_path" => "minimal_skin_white",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#000000",
						"scrubbersToolTipLabelFontColor" => "#FFFFFF",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#eeeeee",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,

						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#000000",
						"atbButtonTextNormalColor" => "#FFFFFF",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#888888",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 41,
						"controller_hide_delay" => 2,
						"start_space_between_buttons" => 7,
						"space_between_buttons" => 9,
						"scrubbers_offset_width" => 4,
						"main_scrubber_offest_top" => 14,
						"time_offset_left_width" => 5,
						"time_offset_right_width" => 3,
						"volume_scrubber_width" => 80,
						"volume_scrubber_offset_right_width" => 0,
						"time_color" => "#919191",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#919191",
						"youtube_quality_button_selected_color" => "#000000",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#000000",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#CDCDCD",
						"main_labels_color" => "#000000",
						"secondary_labels_color" => "#444444",
						"share_and_embed_text_color" => "#777777",
						"input_background_color" => "#b2b2b2",
						"input_color" => "#333333",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#ebebeb",
						"contextMenuBorderColor" => "#ebebeb",
						"contextMenuSpacerColor" => "#CCC",
						"contextMenuItemNormalColor" => "#888888",
						"contextMenuItemSelectedColor" => "#000",
						"contextMenuItemDisabledColor" => "#BBB"
				),
				array(
						// main settings
						"id" => 5,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_modern_white",
						"skin_path" => "modern_skin_white",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#000000",
						"scrubbersToolTipLabelFontColor" => "#FFFFFF",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#eeeeee",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,

						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#000000",
						"atbButtonTextNormalColor" => "#FFFFFF",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#888888",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 42,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 8,
						"space_between_buttons" => 12,
						"scrubbers_offset_width" => 4,
						"main_scrubber_offest_top" => 16,
						"time_offset_left_width" => 1,
						"time_offset_right_width" => -2,
						"volume_scrubber_width" => 90,
						"volume_scrubber_offset_right_width" => 0,
						"time_color" => "#919191",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#919191",
						"youtube_quality_button_selected_color" => "#000000",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#000000",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#CDCDCD",
						"main_labels_color" => "#000000",
						"secondary_labels_color" => "#444444",
						"share_and_embed_text_color" => "#999999",
						"input_background_color" => "#f5f5f5",
						"input_color" => "#333333",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#e3e3e3",
						"contextMenuBorderColor" => "#e3e3e3",
						"contextMenuSpacerColor" => "#CCC",
						"contextMenuItemNormalColor" => "#777",
						"contextMenuItemSelectedColor" =>"#000",
						"contextMenuItemDisabledColor" => "#BBB"
				),
				array(
						// main settings
						"id" => 6,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_classic_white",
						"skin_path" => "classic_skin_white",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#000000",
						"scrubbersToolTipLabelFontColor" => "#FFFFFF",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#eeeeee",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,

						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#000000",
						"atbButtonTextNormalColor" => "#FFFFFF",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#888888",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "no",
						"controller_height" => 43,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 10,
						"space_between_buttons" => 10,
						"scrubbers_offset_width" => 2,
						"main_scrubber_offest_top" => 14,
						"time_offset_left_width" => 2,
						"time_offset_right_width" => 3,
						"volume_scrubber_width" => 80,
						"volume_scrubber_offset_right_width" => 0,
						"time_color" => "#FFFFFF",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#FFFFFF",
						"youtube_quality_button_selected_color" => "#494949",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#000000",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 15,
						"border_color" => "#CDCDCD",
						"main_labels_color" => "#000000",
						"secondary_labels_color" => "#444444",
						"share_and_embed_text_color" => "#444444",
						"input_background_color" => "#828282",
						"input_color" => "#222222",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#ebebeb",
						"contextMenuBorderColor" => "#ebebeb",
						"contextMenuSpacerColor" => "#CCC",
						"contextMenuItemNormalColor" => "#666666",
						"contextMenuItemSelectedColor" => "#000",
						"contextMenuItemDisabledColor" => "#AAA"
				),
				array(
						// main settings
						"id" => 7,
						"initializeOnlyWhenVisible"=>"no",
						"openDownloadLinkOnMobile"=>"no",
						"name" => "skin_metal_white",
						"skin_path" => "metal_skin_white",
						"googleAnalyticsTrackingCode" => "",
						"closeLightBoxWhenPlayComplete" => "no",
						"lightBoxBackgroundOpacity" => ".6",
						"lightBoxBackgroundColor" => "#000000",
						"useFontAwesomeIcons" => "no",
						"preloaderColor1" => "#FFFFFF",
						"preloaderColor2" => "#000000",
						"display_type" => "responsive",
						"showDefaultControllerForVimeo" => "yes",
						"use_resume_on_play" => "no",
						"playsinline" => "yes",
						"fill_entire_video_screen" => "no",
						"showPlaybackRateButton" => "no",
						"defaultPlaybackRate" => 1,
						"greenScreenTolerance" => 200,
						"showPreloader" => "yes",
						"fillEntireScreenWithPoster" => "no",
						"use_HEX_colors_for_skin" => "no",
						
						"normal_HEX_buttons_color" => "#FF0000",
						
						"selected_HEX_buttons_color" => "#FFFFFF",
						"right_click_context_menu" => "developer",
						"add_keyboard_support" => "yes",
						"auto_scale" => "yes",
						"autoplay" => "no",
						"autoPlayText" => "Click To Unmute",
						"loop" => "no",
						"stickyOnScroll" => "no",
						"stickyOnScrollShowOpener" =>"yes",
						"stickyOnScrollWidth" => 700,
						"stickyOnScrollHeight" => 394,
						"showMainScrubberToolTipLabel" => "yes",
						"scrubbersToolTipLabelBackgroundColor" => "#000000",
						"scrubbersToolTipLabelFontColor" => "#FFFFFF",
						"max_width" => 980,
						"max_height" => 551,
						"volume" => .8,
						"start_at_video_source" => 0,
						"show_download_button" => "no",
						"useWithoutVideoScreen" => "no",
						"showScrubberWhenControllerIsHidden" => "yes",
						"showChromecastButton" => "no",
						"ads_text_normal_color" => "#777777",
						"ads_text_selected_color" => "#FFFFFF",
						"ads_border_normal_color" => "#444444",
						"ads_border_selected_color" => "#FFFFFF",
						"bg_color" => "#eeeeee",
						"poster_bg_color" => "#000000",
						"start_at_subtitle" => 1,

						"show_subtitle_button" => "no",
						"subtitles_off_label" => "Subtitle off",
						"open_new_page_at_the_end_of_the_ads"  => "no",
						"ads_buttons_position"  => "right",
						"skip_to_video_text"  => "You can skip to video in:",
						"skip_to_video_button_text" => "Skip add",
						
						//a to b loop
						"useAToB" => "no",
						"atbTimeBackgroundColor" => "transparent",
						"atbTimeTextColorNormal" => "#888888",
						"atbTimeTextColorSelected" => "#000000",
						"atbButtonTextNormalColor" => "#FFFFFF",
						"atbButtonTextSelectedColor" => "#FFFFFF",
						"atbButtonBackgroundNormalColor" => "#888888",
						"atbButtonBackgroundSelectedColor" => "#000000",
						// controller settings
						"use_chromeless" => "no",
						"playVideoOnlyWhenLoggedIn" => "no",
						"goFullScreenOnButtonPlay" => "no",
						"loggedInMessage" => "Please loggin to view this video.",
						"show_popup_ads_close_button" => "yes",
						"showErrorInfo" => "yes",
						"executeCuepointsOnlyOnce" => "no",
						"privateVideoPassword" => "Melinda",
						"encryptVideosPath" => "no",
						"disableDoubleClickFullscreen" => "no",
						"audioVisualizerLinesColor" => "#000000",
						"audioVisualizerCircleColor" => "#FFFFFF",
						"show360DegreeVideoVrButton" => "no",
						"showAudioTracksButton" => "yes",
						"show_controller" => "yes",
						"show_controller_when_video_is_stopped" => "yes",
						"show_volume_scrubber" => "yes",
						"show_volume_button" => "yes",
						"show_time" => "yes",
						"show_youtube_quality_button" => "yes",
						"show_share_button" => "yes",
						"show_embed_button" => "yes",
						"showRewindButton" => "yes",
						"show_fullscreen_button" => "yes",
						"repeat_background" => "yes",
						"controller_height" => 43,
						"controller_hide_delay" => 3,
						"start_space_between_buttons" => 11,
						"space_between_buttons" => 11,
						"scrubbers_offset_width" => 4,
						"main_scrubber_offest_top" => 14,
						"time_offset_left_width" => 0,
						"time_offset_right_width" => 1,
						"volume_scrubber_width" => 90,
						"volume_scrubber_offset_right_width" => 2,
						"time_color" => "#777777",
						"showYoutubeRelAndInfo"=> "no",
						"youtube_quality_button_normal_color" => "#777777",
						"youtube_quality_button_selected_color" => "#000000",
						//apw
						"aopwTitle" => "Advertisement",
						"aopwWidth" => 400,
						"aopwHeight" => 240,
						"aopwBorderSize" => 6,
						"aopwTitleColor" => "#000000",
						//thumbnails preview
						"thumbnails_preview_width" => 196,
						"thumbnails_preview_height" => 110,
						"thumbnails_preview_background_color" => "#000000",
						"thumbnails_preview_border_color" => "#666",
						"thumbnails_preview_label_background_color" => "#666",
						"thumbnails_preview_label_font_color" => "#FFF",
						//sticky
						"showOpener" => "yes",
						"showOpenerPlayPauseButton" => "yes",
						"verticalPosition" => "bottom",
						"horizontalPosition" => "center",
						"showPlayerByDefault" =>"yes",
						"animatePlayer" => "yes",
						"openerAlignment" =>"right",
						"mainBackgroundImagePath" =>  plugin_dir_url(dirname(__FILE__)) . "content/minimal_skin_dark/main-background.png",
						"openerEqulizerOffsetTop" => -1,
						"openerEqulizerOffsetLeft" => 3,
						"offsetX" => 0,
						"offsetY" => 0,
						// logo settings
						"show_logo" => "yes",
						"hide_logo_with_controller" => "yes",
						"logo_position" => "topRight",
						"logo_path" => plugin_dir_url(dirname(__FILE__)) . "content/logo.png",
						"logo_link" => "http://www.webdesign-flash.ro/",
						"logo_margins" => 5,
						
						// embed and info windows settings
						"embed_and_info_window_close_button_margins" => 0,
						"border_color" => "#DDDDDD",
						"main_labels_color" => "#000000",
						"secondary_labels_color" => "#333333",
						"share_and_embed_text_color" => "#999999",
						"input_background_color" => "#d3d3d3",
						"input_color" => "#000000",

						// context menu
						"contextMenuType" => 'default',
						"showScriptDeveloper" => "no",
						"contextMenuBackgroundColor" => "#dcdcdc",
						"contextMenuBorderColor" => "#dcdcdc",
						"contextMenuSpacerColor" => "#CCC",
						"contextMenuItemNormalColor" => "#666666",
						"contextMenuItemSelectedColor" => "#000",
						"contextMenuItemDisabledColor" => "#AAA"
				)
		    );
		}
    }


    // Get data.
    public function get_data(){
	    $cur_data = get_option("fwdevp_data");   
	    $this->settings_ar = $cur_data->settings_ar;
		$this->ads_ar = $cur_data->ads_ar;
		$this->videoStartBehaviour = $cur_data->videoStartBehaviour;
		$this->replaceDF = $cur_data->replaceDF;
		$this->replaceDFSkin = $cur_data->replaceDFSkin;
		$this->keepCookies = $cur_data->keepCookies;
    }
    

    // Set data.
    public function set_data(){
    	update_option("fwdevp_data", $this);
    }
}
?>