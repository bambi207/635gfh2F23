<fieldset id="topHeader" class="ui-widget fwdevp">
	<div>
		<label for="skins"><?php esc_html_e('Select your preset:', 'fwdevp'); ?></label>
	    <select id="skins" class="ui-widget ui-corner-all"></select>
	    <label id="preset_id" for="skins"></label>
		
		<label class="startBH" for="startBH"><?php esc_html_e('Video player start behaviour:', 'fwdevp'); ?></label>
		<select id="startBH" class="ui-widget ui-corner-all">
			<option value="stop">stop</option>
			<option value="default">default</option>
			<option value="pause">pause</option>
		</select>
		<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If set to pause and more then one instance is used all instances will pause except the current playing instance otherwise if set to stop all instances will stop playing and stop the download precess except the current playing instance. If default is used when playing one instance will not stop or pause other instances.', 'fwdevp'); ?>">
		
		<label class="evpCookie" for="evpCookie"><?php esc_html_e('Keep shortcode generator input values:', 'fwdevp'); ?></label>
		<select id="evpCookie" class="ui-widget ui-corner-all">
			<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
			<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
		</select>
		<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If you want to save / keep the last input values in the shortcode generator set this option to yes otherwise set it to no.', 'fwdevp'); ?>">
	 <div>
	 <div class="replace">
		<label class="replaceDF" for="replaceDF"><?php esc_html_e('Replace default player:', 'fwdevp'); ?></label>
		<select id="replaceDF" class="ui-widget ui-corner-all">
			<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
			<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
		</select>
		<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If set to yes EVP will replace the default WordPress Video Player, Youtube and Vimeo.', 'fwdevp'); ?>">

		<label class="replaceDFSkin" for="replaceDFSkin"><?php esc_html_e('Replace default player skin:', 'fwdevp'); ?></label>
		<select id="replaceDFSkin" class="ui-widget ui-corner-all">
			
		</select>
		<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Select the skin that you want to use for the replaced default player.', 'fwdevp'); ?>">
	 </div>

	 <p id="tips"></p>
</fieldset>

<form class="form fwdevp" action="" method="post">
	<div id="tabs">
	  	<ul class="menu">
		    <li><a href="#tab1"><img src=<?php echo $iconsPath . "tab1-icon.png" ?>><span><?php esc_html_e('Main settings', 'fwdevp'); ?></span></a></li>
		    <li><a href="#tab2"><img src=<?php echo $iconsPath . "controler-icon.png" ?>><span><?php esc_html_e('Controller settings', 'fwdevp'); ?></span></a></li>
		    <li><a href="#tab3"><img src=<?php echo $iconsPath . "tab3-icon.png" ?>><span><?php esc_html_e('Logo settings', 'fwdevp'); ?></span></a></li>
		    <li><a href="#tab4"><img src=<?php echo $iconsPath . "tab4-icon.png" ?>><span><?php esc_html_e('Embed and info windows settings', 'fwdevp'); ?></span></a></li>
		    <li><a href="#tab5"><img src=<?php echo $iconsPath . "tab5-icon.png" ?>><span><?php esc_html_e('Ads settings', 'fwdevp'); ?></span></a></li>
		    <li><a href="#tab6"><img src=<?php echo $iconsPath . "subtitle-icon.png" ?>><span><?php esc_html_e('Subtitle settings', 'fwdevp'); ?></span></a></li>
			<li><a href="#tab7"><img src=<?php echo $iconsPath . "tab6-icon.png" ?>><span><?php esc_html_e('Advertisement window on pause settings', 'fwdevp'); ?></span></a></li>
			<li><a href="#tab8"><img src=<?php echo $iconsPath . "tab2-icon.png" ?>><span><?php esc_html_e('Sticky display type settings', 'fwdevp'); ?></span></a></li>
			<li><a href="#tab9"><img src=<?php echo $iconsPath . "lightbox-icon.png" ?>><span><?php esc_html_e('Lightbox display type settings', 'fwdevp'); ?></span></a></li>
			<li><a href="#tab10"><img src=<?php echo $iconsPath . "tab1-icon.png" ?>><span><?php esc_html_e('A to B loop settings', 'fwdevp'); ?></span></a></li>
			<li><a href="#tab11"><img src=<?php echo $iconsPath . "tab1-icon.png" ?>><span><?php esc_html_e('Tumbnails Preview', 'fwdevp'); ?></span></a></li>
			<li><a href="#tab12"><img src=<?php echo $iconsPath . "tab1-icon.png" ?>><span><?php esc_html_e('Right click context menu', 'fwdevp'); ?></span></a></li>
	  	</ul>
	 
	  	<div id="tab1" class="tab">
			<table>
    			<tr>
		    		<td>
		    			<label for="name"><?php esc_html_e('Preset name:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="name" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
		    	<tr>
		    		<td>
		    			<label for="skin_path"><?php esc_html_e('Skin type:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="skin_path" class="ui-corner-all">
							<option value="minimal_skin_dark">minimal-skin-dark</option>
							<option value="modern_skin_dark">modern-skin-dark</option>
							<option value="classic_skin_dark">classic-skin-dark</option>
							<option value="metal_skin_dark">metal-skin-dark</option>
							<option value="minimal_skin_white">minimal-skin-white</option>
							<option value="modern_skin_white">modern-skin-white</option>
							<option value="classic_skin_white">classic-skin-white</option>
							<option value="metal_skin_white">metal-skin-white</option>
							<option value="hex_dark">hex-dark</option>
							<option value="hex_white">hex-white</option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="useFontAwesomeIcons"><?php esc_html_e('Use vector icons:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="useFontAwesomeIcons" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="display_type"><?php esc_html_e('Display type:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="display_type" class="ui-corner-all">
							<option value="responsive">responsive</option>
							<option value="fullscreen">fullscreen</option>
							<option value="sticky">sticky</option>
							<option value="lightbox">lightbox</option>
							<option value="afterparent">after-parent</option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This allows to change the display type, responsive is setting the player to be responsive based on the specified player width and height, fullscreen it will open the player in fullscreen, after-parent it will resize the player based on the parent div, this is useful if you have a flexible div and you want the player to resize based the div width and height, sticky will keep the player over the page layout in a sticky form, lightbox will open the player in a modal / lightbox window.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="playsinline"><?php esc_html_e('Plays inline:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="playsinline" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This option affects the player when the video is playing on IOS, if you want the IOS device to use the dafault player set this to no otherwise set it to yes.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="stickyOnScroll"><?php esc_html_e('Use sticky on scroll:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="stickyOnScroll" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Set this to yes to keep EVP visible when it is outside the viewport otherwise leave it to no.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="stickyOnScrollShowOpener"><?php esc_html_e('Show sticky on scroll open / close button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="stickyOnScrollShowOpener" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Use or not the show or hide button when then player is in sticky on scroll mode.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="stickyOnScrollWidth"><?php esc_html_e('Sticky on scroll player maximum width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="stickyOnScrollWidth" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This value represents the player maximum width in px units for the player when it is in sticky on scroll mode, think of this property as it would be the \'max-width\' CSS property.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="stickyOnScrollHeight"><?php esc_html_e('Sticky on scroll player maximum height:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="stickyOnScrollHeight" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This value represents the player maximum height in px units for the player when it is in sticky on scroll mode, think of this property as it would be the \'max-height\' CSS property.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="initializeOnlyWhenVisible"><?php esc_html_e('Initialize only when visible:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="initializeOnlyWhenVisible" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Lazy scrolling / loading, the posibility to initialize EVP on scroll when the player is visible in the page, this way for example if the player is in a section of a webpage that is not visible it will not be initialized / play, instead EVP will be initalized / play only when the user is scrolling to that section in which the player is added.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="openDownloadLinkOnMobile"><?php esc_html_e('Open video in new window on download:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="openDownloadLinkOnMobile" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('By default on mobile devices when the download button is used a send window is opened, if this is option is set to yes instead of the send window the video will be opened in a new tab.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="add_keyboard_support"><?php esc_html_e('Add keyboard support:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="add_keyboard_support" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="auto_scale"><?php esc_html_e('Autoscale:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="auto_scale" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="autoplay"><?php esc_html_e('Autoplay:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="autoplay" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="autoPlayText"><?php esc_html_e('Autoplay text:', 'fwdevp'); ?></label>
		    		</td> 
		    		<td>
		    			<input type="text" id="autoPlayText" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If autoplay is set to yes the video will start muted and if this option has a text it will appear in a button over the video,  when clicked this button will unmute the video. If you don\'t want this button leave this option empty.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
			</table>
			<table>
				<tr>
		    		<td>
		    			<label for="loop"><?php esc_html_e('Loop:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="loop" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="show_popup_ads_close_button"><?php esc_html_e('Show popup ads close button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_popup_ads_close_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="show_controller"><?php esc_html_e('Show controller:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_controller" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="use_chromeless"><?php esc_html_e('Use chromeless:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="use_chromeless" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="fill_entire_video_screen"><?php esc_html_e('Fill entire video screen:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="fill_entire_video_screen" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This feature will allow to fill the gaps of the video player, you can have for example a real full width player.', 'fwdevp'); ?>">
			
		    		</td>
					
		    	</tr>
		    	
		    	<tr>
		    		<td>
		    			<label for="use_resume_on_play"><?php esc_html_e('Use resume / remember on play:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="use_resume_on_play" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Resume / remember function which marks the last play position of the video when the browser is closed and remembers it when you come back to watch video again.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="use_HEX_colors_for_skin"><?php esc_html_e('Use HEX / CSS colors:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="use_HEX_colors_for_skin" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This feature allows to add hexadecimal colors to all buttons and some player elements just like it\'s done with CSS and even more, we have done it in a cool way that all graphics will retain the texture and at the same time apply the chosen color. Please note that this feature will work with all skins but we created a custom dark skin and a custom white skin specially for this, I suggest to use this skins, if you are using a dark theme set the \'Skin type:\' option to hex_dark if is the white theme set \'Skin type:\' to hex_white, both skins can be found in the plugin directory wp-plugins/fwdevp/content.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="normal_HEX_buttons_color"><?php esc_html_e('Normal HEX / CSS color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="normal_HEX_buttons_color" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="max_width"><?php esc_html_e('Player maximum width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="max_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This value represents the player maximum width in px units, think of this property as it would be the \'max-width\' CSS property.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="max_height"><?php esc_html_e('Player maximum height:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="max_height" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This value represents the player maximum height in px units, think of this property as it would be the \'max-height\' CSS property.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="volume"><?php esc_html_e('Volume:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="volume" class="text ui-widget-content ui-corner-all">
		    			<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is the volume level of the player. It must be a float value between 0 and 1.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="googleAnalyticsTrackingCode"><?php esc_html_e('Google analytics tracking code:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="googleAnalyticsTrackingCode" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If you want to use google analytics set this option to the google analytics tracking code otherwise leave it blank.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="bg_color"><?php esc_html_e('Background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="bg_color" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="fillEntireScreenWithPoster"><?php esc_html_e('Fill entire screen with the poster:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="fillEntireScreenWithPoster" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('By default the video poster is set to be visible completely, if you want the video poster to fill the entire video screen and leave no gaps set this option to yes.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="poster_bg_color"><?php esc_html_e('Poster background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="poster_bg_color" />
		    		</td>
		    	</tr>
		    </table>
			<table>
				<tr>
		    		<td>
		    			<label for="greenScreenTolerance"><?php esc_html_e('Green screen tolerance:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="greenScreenTolerance" class="text ui-widget-content ui-corner-all">
		    			<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('A number from 0 to 256 that repreents fine tunning for removing the green pixles from the video background, by default is 200, modify this valye only if necessary.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
			
				<tr>
		    		<td>
		    			<label for="showPreloader"><?php esc_html_e('Show preloader:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
					<select id="showPreloader" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="preloaderColor1"><?php esc_html_e('Preloader color 1:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="preloaderColor1" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="preloaderColor2"><?php esc_html_e('Preloader color 2:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="preloaderColor2" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="disableDoubleClickFullscreen"><?php esc_html_e('Disable go fullscreen on double click:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
					<select id="disableDoubleClickFullscreen" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="executeCuepointsOnlyOnce"><?php esc_html_e('Call cupoints only once:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="executeCuepointsOnlyOnce" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				
				<tr>
		    		<td>
		    			<label for="audioVisualizerCircleColor"><?php esc_html_e('Audio visualizer circle color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="audioVisualizerCircleColor" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="audioVisualizerLinesColor"><?php esc_html_e('Audio visualizer bars color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="audioVisualizerLinesColor" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="privateVideoPassword"><?php esc_html_e('Private videos password:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="privateVideoPassword" class="text ui-widget-content ui-corner-all">
		    			<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If a private video is used the password for the video / videos can be set here.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="playVideoOnlyWhenLoggedIn"><?php esc_html_e('Play video only when logged in:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="playVideoOnlyWhenLoggedIn" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>

		    	<tr>
		    		<td>
		    			<label for="goFullScreenOnButtonPlay"><?php esc_html_e('Go fullscreen on play:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="goFullScreenOnButtonPlay" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If this feature is set to yes when the play button is clicked or tapped the player will start playing the video and go in fullscreen at the same time.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>

				<tr>
		    		<td>
		    			<label for="loggedInMessage"><?php esc_html_e('Message to show if user is not loggedin:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="loggedInMessage" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="showErrorInfo"><?php esc_html_e('Show error / info window:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showErrorInfo" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="showDefaultControllerForVimeo"><?php esc_html_e('Show default controller when playing Vimeo videos:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showDefaultControllerForVimeo" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Normal vimeo videos do not allow to remove the player default controlls so leave this option to no, if you are using vimeo pro video and disabled the vimeo video controller set this to yes this way the EVP controller can be used.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="useWithoutVideoScreen"><?php esc_html_e('Use without video screen:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="useWithoutVideoScreen" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If you want to use EVP for audio (.mp3) it is possbile to only have the plyer controller without the video screen.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
			</table>
		</div>

		<div id="tab2" class="tab">
		  	<table>
				<tr>
		    		<td>
		    			<label for="show_controller_when_video_is_stopped"><?php esc_html_e('Show controller when video is stopped:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_controller_when_video_is_stopped" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="show_volume_scrubber"><?php esc_html_e('Show volume scrubber:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_volume_scrubber" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="show_volume_button"><?php esc_html_e('Show volume button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_volume_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="show_time"><?php esc_html_e('Show time:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_time" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="show_youtube_quality_button"><?php esc_html_e('Show quality button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_youtube_quality_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="showPlaybackRateButton"><?php esc_html_e('Show playback rate button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showPlaybackRateButton" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>

				<tr>
		    		<td>
		    			<label for="show_download_button"><?php esc_html_e('Show download button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_download_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>

				<tr>
		    		<td>
		    			<label for="show_share_button"><?php esc_html_e('Show share button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_share_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="show_subtitle_button"><?php esc_html_e('Show subtitle button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_subtitle_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>

		    	<tr>
		    		<td>
		    			<label for="showAudioTracksButton"><?php esc_html_e('Show audio tracks button:', 'fwdevp');?></label>
		    		</td>
		    		<td>
		    			<select id="showAudioTracksButton" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp');?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp');?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Support for HLS .m3u8 and video / mp4 multiple audio tracks, please note that for .mp4 / video this feature is limited by browser support, browsers that do not have support for the HTMLMediaElement.audioTracks video property will not display the headphone button that allows changing the video audio track.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="show_embed_button"><?php esc_html_e('Show embed button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_embed_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
		    	
		    	<tr>
		    		<td>
		    			<label for="showChromecastButton"><?php esc_html_e('Show chromecast button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showChromecastButton" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Show or hide the chormecast button (this only works on google chrome and a https protocol).', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="show_fullscreen_button"><?php esc_html_e('Show fullscreen button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_fullscreen_button" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="show360DegreeVideoVrButton"><?php esc_html_e('Show 360 degree VR button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show360DegreeVideoVrButton" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('To enable vr for 360 videos set this feature to yes otherwise leave it to no.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="showRewindButton"><?php esc_html_e('Show rewind 10 seconds button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showRewindButton" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
			</table>

			<table>
				<tr>
		    		<td>
		    			<label for="repeat_background"><?php esc_html_e('Repeat background:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="repeat_background" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This option is like the CSS \'background-repeat\' property for the controller background image. If set to \'no\' it will expand the image to fill the controller size.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="showMainScrubberToolTipLabel"><?php esc_html_e('Show main scrubber tooltip:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showMainScrubberToolTipLabel" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="showScrubberWhenControllerIsHidden"><?php esc_html_e('Show main scrubber when controller is hidden:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showScrubberWhenControllerIsHidden" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>

		    	<tr>
		    		<td>
		    			<label for="showYoutubeRelAndInfo"><?php esc_html_e('Show Youtube UI elements:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showYoutubeRelAndInfo" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Show or hide the YouTube UI elements (Title/Share/Watch later/Related videos/Logo).', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="scrubbersToolTipLabelBackgroundColor"><?php esc_html_e('Main scrubber tooltip background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="scrubbersToolTipLabelBackgroundColor" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="scrubbersToolTipLabelFontColor"><?php esc_html_e('Main scrubber tooltip font color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="scrubbersToolTipLabelFontColor" />
		    		</td>
		    	</tr>
				
	    		<tr>
		    		<td>
		    			<label for="controller_height"><?php esc_html_e('Controller height:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="controller_height" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="controller_hide_delay"><?php esc_html_e('Controller hide delay:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="controller_hide_delay" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is a number that represents the seconds until the control bar is hiding after a period of inactivity.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="start_space_between_buttons"><?php esc_html_e('Start space between buttons:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="start_space_between_buttons" class="text ui-widget-content ui-corner-all">
		    			<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" id="start_space_between_buttons_img"  title="">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="space_between_buttons"><?php esc_html_e('Space between buttons:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="space_between_buttons" class="text ui-widget-content ui-corner-all">
		    			<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" id="space_between_buttons_img"  title="">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="scrubbers_offset_width"><?php esc_html_e('Scrubbers offset width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="scrubbers_offset_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is a number that represents the total amount in pixels removed from the scrubber bars when they are at the end (useful based on the skin type).', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="main_scrubber_offest_top"><?php esc_html_e('Main scrubber offset top:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="main_scrubber_offest_top" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is the amount in pixels to push the main scrubber up when the controller is hiding.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="time_offset_left_width"><?php esc_html_e('Time offset left width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="time_offset_left_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is a number that represents an addition in px to the space between the time indicator left side and the scrubber.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="time_offset_right_width"><?php esc_html_e('Time offset right width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="time_offset_right_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is a number that represents an addition in px to the space between the time indicator right side and the volume button or any other button that will follow the time indicator.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="volume_scrubber_width"><?php esc_html_e('Volume scrubber width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="volume_scrubber_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is a number that represents the width of the volume scrubber.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
			</table>
			<table>
				<tr>
		    		<td>
		    			<label for="volume_scrubber_offset_right_width"><?php esc_html_e('Volume scrubber offset right width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="volume_scrubber_offset_right_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This is a number that represents an addition in px to the space between the volume scrubber right side and the facebook share button or any other button that will follow the volume scrubber.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="time_color"><?php esc_html_e('Time color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="time_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="youtube_quality_button_normal_color"><?php esc_html_e('Youtube quality button normal color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="youtube_quality_button_normal_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="youtube_quality_button_selected_color"><?php esc_html_e('Youtube quality button selected color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="youtube_quality_button_selected_color" />
		    		</td>
		    	</tr>
		    </table>
		</div>

		<div id="tab3" class="tab">
			<table>
				<tr>
		    		<td>
		    			<label for="show_logo"><?php esc_html_e('Show logo:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="show_logo" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="hide_logo_with_controller"><?php esc_html_e('Hide logo with controller:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="hide_logo_with_controller" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="logo_position"><?php esc_html_e('Logo position:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="logo_position" class="ui-corner-all">
							<option value="topRight"><?php esc_html_e('top-right', 'fwdevp'); ?></option>
							<option value="topLeft"><?php esc_html_e('top-left', 'fwdevp'); ?></option>
							<option value="bottomRight"><?php esc_html_e('bottom-righ', 'fwdevp'); ?>t</option>
							<option value="bottomLeft"><?php esc_html_e('bottom-left', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="logo_path"><?php esc_html_e('Logo path:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="logo_path" class="text ui-widget-content ui-corner-all">
		    			<button id="evp_logo_bg_image_btn"><?php esc_html_e('Add Image', 'fwdevp'); ?></button>
		    		</td>
		    		<td>
		    			<img src="" id="evp_logo_upload_img">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="logo_link"><?php esc_html_e('Logo link:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="logo_link" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="logo_margins"><?php esc_html_e('Logo margins:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="logo_margins" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
			</table>
		</div>

		<div id="tab4" class="tab">
			<table>
				<tr>
		    		<td>
		    			<label for="embed_and_info_window_close_button_margins"><?php esc_html_e('Embed and info window close button margins:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="embed_and_info_window_close_button_margins" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="border_color"><?php esc_html_e('Border color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="border_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="main_labels_color"><?php esc_html_e('Main labels color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="main_labels_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="secondary_labels_color"><?php esc_html_e('Secondary labels color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="secondary_labels_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="share_and_embed_text_color"><?php esc_html_e('Share and embed text color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="share_and_embed_text_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="input_background_color"><?php esc_html_e('Input background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="input_background_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="input_color"><?php esc_html_e('Input color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="input_color" />
		    		</td>
		    	</tr>
			</table>
			
			<img src=<?php echo $this->_dir_url . "content/spaces/embedWindow.jpg" ?>>
		</div>

		<div id="tab5" class="tab">
			<table>
				<tr>
		    		<td>
		    			<label for="open_new_page_at_the_end_of_the_ads"><?php esc_html_e('Open new page at the end of the ads:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="open_new_page_at_the_end_of_the_ads" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="ads_buttons_position"><?php esc_html_e('Ads buttons position:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="ads_buttons_position" class="ui-corner-all">
							<option value="left"><?php esc_html_e('left', 'fwdevp'); ?></option>
							<option value="right"><?php esc_html_e('right', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="skip_to_video_text"><?php esc_html_e('Skip to video text:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="skip_to_video_text" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="skip_to_video_button_text"><?php esc_html_e('Skip to video button text:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="skip_to_video_button_text" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="ads_text_normal_color"><?php esc_html_e('Ads text normal color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="ads_text_normal_color" />
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="ads_text_selected_color"><?php esc_html_e('Ads text selected color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="ads_text_selected_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="ads_border_normal_color"><?php esc_html_e('Ads border normal color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="ads_border_normal_color" />
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="ads_border_selected_color"><?php esc_html_e('Ads border selected color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="ads_border_selected_color" />
		    		</td>
		    	</tr>
			</table>
		</div>
		
		<div id="tab6" class="tab">
			<table>
				<tr>
		    		<td>
		    			<label for="subtitles_off_label"><?php esc_html_e('Subtitle off label:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="subtitles_off_label" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
			</table>
		</div>
		
		<div id="tab7" class="tab">
			<table>
				<tr>
		    		<td>
		    			<label for="aopwTitle"><?php esc_html_e('Title:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="aopwTitle" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="aopwWidth"><?php esc_html_e('Maximum width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="aopwWidth" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="aopwHeight"><?php esc_html_e('Maximum height:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="aopwHeight" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="aopwBorderSize"><?php esc_html_e('Advertisement border size:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="aopwBorderSize" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="aopwTitleColor"><?php esc_html_e('Title color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="aopwTitleColor" class="text ui-widget-content ui-corner-all">
		    		</td>
		    	</tr>
				
				
			</table>
		</div>
		
		<div id="tab8" class="tab">
			<table>
				
				<tr>
		    		<td>
		    			<label for="showPlayerByDefault"><?php esc_html_e('Show player by default:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showPlayerByDefault" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="animatePlayer"><?php esc_html_e('Animate player:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="animatePlayer" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="showOpener"><?php esc_html_e('Show opener:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showOpener" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="showOpenerPlayPauseButton"><?php esc_html_e('Show opener play / pause button:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showOpenerPlayPauseButton" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="openerAlignment"><?php esc_html_e('Opener alignment:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="openerAlignment" class="ui-corner-all">
							<option value="left"><?php esc_html_e('left', 'fwdevp'); ?></option>
							<option value="right"><?php esc_html_e('right', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				
				<tr>
		    		<td>
		    			<label for="verticalPosition"><?php esc_html_e('Player vertical position:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="verticalPosition" class="ui-corner-all">
							<option value="bottom"><?php esc_html_e('bottom', 'fwdevp'); ?></option>
							<option value="top"><?php esc_html_e('top', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
				<tr>
		    		<td>
		    			<label for="horizontalPosition"><?php esc_html_e('Player horizontal position:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="horizontalPosition" class="ui-corner-all">
							<option value="left"><?php esc_html_e('left', 'fwdevp'); ?></option>
							<option value="center"><?php esc_html_e('center', 'fwdevp'); ?></option>
							<option value="right"><?php esc_html_e('right', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
				
    			<tr>
		    		<td>
		    			<label for="openerEqulizerOffsetTop"><?php esc_html_e('Equalizer offset top:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="openerEqulizerOffsetTop" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This number represents the opener equalizer left offset (left margin).', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				
    			<tr>
		    		<td>
		    			<label for="openerEqulizerOffsetLeft"><?php esc_html_e('Equalizer offset left:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="openerEqulizerOffsetLeft" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This number represents the opener equalizer top offset (top margin).', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="offsetX"><?php esc_html_e('Offset X:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="offsetX" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This value represents an offset in px on the x axis, basically if you want to push the player a few px on the x axis from it\'s position you can do it by modifying this option.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="offsetY"><?php esc_html_e('Offset Y:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="offsetY" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This value represents an offset in px on the y axis, basically if you want to push the player a few px on the y axis from it\'s position you can do it by modifying this option.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
				<tr>
		    		<td>
		    			<label for="mainBackgroundImagePath"><?php esc_html_e('Background image path:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<div id="cov_bg_image_div">
				    		<table>
				    			<tr>
						    		<td>
						    			<input id="mainBackgroundImagePath" type="text" class="text ui-widget-content ui-corner-all">
						    		 	<button id="evp_bg_image_btn"><?php esc_html_e('Add Image', 'fwdevp'); ?></button>
						    		</td>
						    		<td>
						    			<img src="" id="evp_bg_upload_img">
						    		</td>
						    	</tr>
						    </table>
						</div>
		    		</td>
		    	</tr>
				
			</table>
		</div>
		
		<div id="tab9" class="tab">
			<table>
				<tr>
					<td>
						<label for="closeLightBoxWhenPlayComplete"><?php esc_html_e('Close lightbox when video has finished playing:', 'fwdevp'); ?></label>
					</td>
					<td>
						<select id="closeLightBoxWhenPlayComplete" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<label for="lightBoxBackgroundOpacity"><?php esc_html_e('Background opacity:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input type="text" id="lightBoxBackgroundOpacity" class="text ui-widget-content ui-corner-all">
					</td>
				</tr>
				<tr>
					<td>
						<label for="lightBoxBackgroundColor"><?php esc_html_e('Youtube quality button normal color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="lightBoxBackgroundColor" />
					</td>
				</tr>
			</table>
		</div>
		
		<div id="tab10" class="tab">
			<table>
				<tr>
					<td>
						<label for="useAToB"><?php esc_html_e('Use a to be loop:', 'fwdevp'); ?></label>
					</td>
					<td>
						<select id="useAToB" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The a to b loop feature is basically a plugin for EVP this way it will not add to the total file size if it is not used. To enable it set it to yes otherwise set it to no.', 'fwdevp'); ?>">
					</td>
				</tr>
				<tr>
					<td>
						<label for="atbTimeTextColorNormal"><?php esc_html_e('Time text normal color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="atbTimeTextColorNormal" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="atbTimeTextColorSelected"><?php esc_html_e('Time text selected color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="atbTimeTextColorSelected" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="atbButtonTextNormalColor"><?php esc_html_e('Button text normal color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="atbButtonTextNormalColor" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="atbButtonTextSelectedColor"><?php esc_html_e('Button text selected color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="atbButtonTextSelectedColor" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="atbButtonBackgroundNormalColor"><?php esc_html_e('Button background normal color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="atbButtonBackgroundNormalColor" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="atbButtonBackgroundSelectedColor"><?php esc_html_e('Button background selected color:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input id="atbButtonBackgroundSelectedColor" />
					</td>
				</tr>
			</table>
		</div>

		<div id="tab11" class="tab">
			<table>
				<tr>
		    		<td>
		    			<label for="thumbnails_preview_width"><?php esc_html_e('Thumbnail width:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="thumbnails_preview_width" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Thumbnail preview width in px.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="thumbnails_preview_height"><?php esc_html_e('Thumbnail height:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input type="text" id="thumbnails_preview_height" class="text ui-widget-content ui-corner-all">
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Thumbnail preview height in px.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="thumbnails_preview_background_color"><?php esc_html_e('Background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="thumbnails_preview_background_color" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="thumbnails_preview_border_color"><?php esc_html_e('Border color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="thumbnails_preview_border_color" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="thumbnails_preview_label_background_color"><?php esc_html_e('Time background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="thumbnails_preview_label_background_color" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="thumbnails_preview_label_font_color"><?php esc_html_e('Time text color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="thumbnails_preview_label_font_color" />
		    		</td>
		    	</tr>
			</table>
		</div>

		<div id="tab12" class="tab">
			<table>
				<tr>
					<td>
		    			<label for="contextMenuType"><?php esc_html_e('Show right click context menu:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="contextMenuType" class="ui-corner-all">
							<option value="default"><?php esc_html_e('default', 'fwdevp'); ?></option>
							<option value="disabled"><?php esc_html_e('disabled', 'fwdevp'); ?></option>
							<option value="none"><?php esc_html_e('none', 'fwdevp'); ?></option>
						</select>
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="showScriptDeveloper"><?php esc_html_e('Show developer link:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<select id="showScriptDeveloper" class="ui-corner-all">
							<option value="yes"><?php esc_html_e('yes', 'fwdevp'); ?></option>
							<option value="no"><?php esc_html_e('no', 'fwdevp'); ?></option>
						</select>
						<img class="img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Ads an extra option in the right click context menu with a link for the developer website, if you want to support this pluogin please set this option to yes.', 'fwdevp'); ?>">
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="contextMenuBackgroundColor"><?php esc_html_e('Background color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="contextMenuBackgroundColor" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="contextMenuBorderColor"><?php esc_html_e('Border color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="contextMenuBorderColor" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="contextMenuSpacerColor"><?php esc_html_e('Spacer color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="contextMenuSpacerColor" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="contextMenuItemNormalColor"><?php esc_html_e('Menu item normal color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="contextMenuItemNormalColor" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="contextMenuItemSelectedColor"><?php esc_html_e('Menu item selected color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="contextMenuItemSelectedColor" />
		    		</td>
		    	</tr>
		    	<tr>
		    		<td>
		    			<label for="contextMenuItemDisabledColor"><?php esc_html_e('Menu item disabled color:', 'fwdevp'); ?></label>
		    		</td>
		    		<td>
		    			<input id="contextMenuItemDisabledColor" />
		    		</td>
		    	</tr>
			</table>
		</div>
	</div>
	
	<input type="hidden" id="settings_data" name="settings_data" value="">
	
	<input id="add_btn" type="submit" name="submit" value="<?php esc_html_e('Add new preset', 'fwdevp'); ?>" />
	<input id="update_btn" type="submit" name="submit" value="<?php esc_html_e('Update preset settings', 'fwdevp'); ?>" />
	<input id="del_btn" type="submit" name="submit" value="<?php esc_html_e('Delete preset', 'fwdevp'); ?>" />
	
	<?php wp_nonce_field("fwdevp_general_settings_update", "fwdevp_general_settings_nonce"); ?>
</form>

<?php if(!(empty($msg))): ?>
<div class='fwd-updated'>
	<p class="fwd-updated-p">
		<?php echo esc_html($msg); ?>
	</p>
</div>
<?php endif; ?>