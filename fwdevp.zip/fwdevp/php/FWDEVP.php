<?php
/**
 * Main class.
 *
 * @package fwdevp
 * @since fwdevp 1.0
 */

class FWDEVP{
	
	const MIN_WP_VER 	=  "3.5.0";
	const CAPABILITY 	= "edit_fwdevp";
	const VERSION 		= 	9.2;
	private $_data;
	private $_dir_url;
    private static $_evp_id = 0;
    
    // Initialize.
    public function init(){
		$this->_dir_url = plugin_dir_url(dirname(__FILE__));

    	// Set hooks.
    	add_action("admin_menu", array($this, "fwdevp_add_plugin_menu"));
    	add_action('admin_enqueue_scripts', array($this, "fwdevp_enqueue_admin_files"));
		add_action("wp_enqueue_scripts", array($this, "fwdevp_add_scripts_and_styles"));
		add_shortcode("fwdevp", array($this, "fwdevp_set_player"));
		add_shortcode('fwdevp-lightbox', array($this, "fwdevp_shortcode_lightbox"));
		
		// Set data.
		$this->_data = new FWDEVPData();
		$this->_data->init();	

		// Overwrite default player.
		if(!is_admin()){
			$this->fwdevp_replace_wp_default_player();
		}

		// Make plugin available for translation.
		load_plugin_textdomain('fwdevp', false, basename(realpath(__DIR__ . '/..')) . '/languages/');
    }


    // Add menu/meta boxes.
    public function fwdevp_add_plugin_menu(){
		
    	// Add menu.
        add_menu_page("Easy Video Player", "Easy Video Player", FWDEVP::CAPABILITY, "fwdevp-menu-general-settings", array($this, "fwdevp_set_general_settings"), esc_url_raw($this->_dir_url) . "content/icons/menu-icon.png");
		add_submenu_page("fwdevp-menu-general-settings", __("General settings",'fwdevp'), __("General settings",'fwdevp'), FWDEVP::CAPABILITY, "fwdevp-menu-general-settings");
		add_submenu_page("fwdevp-menu-general-settings", __("CSS Editor",'fwdevp'), __("CSS Editor",'fwdevp'), FWDEVP::CAPABILITY, "fwdevp-menu-css-editor", array($this, "fwdevp_set_css_editor"));
       	
       	// Add meta boxes.
       	$post_type_screens = array("post", "page");
       	$args = array(
	       'public'   => true,
	       '_builtin' => false,
	    );

       	$custom_post_types = get_post_types($args);
       	foreach ($custom_post_types as $screen){
       		$post_type_screens[] = $screen;
       	}

    	foreach ($post_type_screens as $screen){
       		add_meta_box("fwdevp-shortcode-generator", "Easy Video Player Shortcode Generator",  array($this, "fwdevp_set_custom_meta_box"), $screen, "normal", "low");
    	}
    }


    // Add backend files.
    public function fwdevp_enqueue_admin_files($hook){

    	// CSS editor.
    	if($hook == 'easy-video-player_page_fwdevp-menu-css-editor'){
    		wp_enqueue_style("fwdevp_fwd_ui_css", esc_url_raw($this->_dir_url) . "css/fwd_ui.css", array(), '1.10.4');
    		wp_enqueue_style("fwdevp_css_editor", esc_url_raw($this->_dir_url) . "css/css_editor.css", array(), FWDEVP::VERSION);
    		wp_enqueue_script("fwdevp_css_editor", esc_url_raw($this->_dir_url) . "js/css_editor.js", array(), FWDEVP::VERSION, true);

    	// General settings.
    	}else if($hook == 'toplevel_page_fwdevp-menu-general-settings'){
    		wp_enqueue_style("fwdevp_general_settings_css", esc_url_raw($this->_dir_url) . "css/general_settings.css", array(), FWDEVP::VERSION);
    		wp_enqueue_style("fwdevp_fwd_ui_css", esc_url_raw($this->_dir_url) . "css/fwd_ui.css", array(), '1.10.4');
			wp_enqueue_script("fwdevp_fwdtooltip", esc_url_raw($this->_dir_url) . "js/fwdtooltip.js", array(), '1.0');
			wp_enqueue_script("jquery-ui-tabs");
	    	wp_enqueue_style("fwdevp_spectrum_css", esc_url_raw($this->_dir_url) . "css/spectrum.css");
	    	wp_enqueue_script("fwdevp_spectrum_script", esc_url_raw($this->_dir_url) . "js/spectrum.js");
			wp_enqueue_media();
			wp_enqueue_script("fwdevp_general_settings", esc_url_raw($this->_dir_url) . "js/general_settings.js" , array(), FWDEVP::VERSION, true);

		// Shortcode.
    	}else if($hook == 'post.php' || $hook == 'post-new.php'){
			wp_enqueue_style("fwdevp_fwd_ui_css", esc_url_raw($this->_dir_url) . "css/fwd_ui.css", array(), '1.10.4');
			wp_enqueue_script("fwdevp_fwdtooltip", esc_url_raw($this->_dir_url) . "js/fwdtooltip.js", array(), '1.0');
			wp_enqueue_script("jquery-ui-dialog");
			wp_enqueue_script("fwdevp_evp_script", esc_url_raw($this->_dir_url) . "js/FWDEVP.js" , array(), FWDEVP::VERSION);
			if(!preg_match('/acora/', FWDEVP_TEXT_DOMAIN)){
				wp_enqueue_style("fwdevp_evp_global_css", esc_url_raw($this->_dir_url) . "content/global.css" , array(), FWDEVP::VERSION);
			}
			wp_enqueue_style("fwdevp_shortcode_css", esc_url_raw($this->_dir_url) . "css/shortcode.css" , array(), FWDEVP::VERSION);
			wp_enqueue_script("fwdevp_shortcode", esc_url_raw($this->_dir_url) . "js/shortcode.js" , array(), FWDEVP::VERSION, true);
		}
    }


   	// Add front JS/CSS files.
    public function fwdevp_add_scripts_and_styles(){
     	global $post, $wpdb;
     	if(empty($post)) return;

		$shortcode_found = false;
       	if(has_shortcode($post->post_content, 'fwdevp') || $this->_data->replaceDF == "yes"){
          	$shortcode_found = true;
       	}else if(isset($post->ID)){ 
          	$result = $wpdb->get_var($wpdb->prepare(
            "SELECT count(*) FROM $wpdb->postmeta " .
            "WHERE post_id = %d and meta_value LIKE '%%fwdevp%%'", $post->ID));
          	$shortcode_found = !empty($result);
       	}
       	
       	// Uncomment this to add the front required js/css files only if the shortcode is found in the page/post.
		//if (!empty($shortcode_found)){
       		if(!preg_match('/acora/', FWDEVP_TEXT_DOMAIN)){
				wp_enqueue_style("fwdevp", esc_url_raw($this->_dir_url) . "css/fwdevp.css", array(), FWDEVP::VERSION);
			}
			wp_enqueue_script("fwdevp", esc_url_raw($this->_dir_url) . "js/FWDEVP.js", array(), FWDEVP::VERSION, true);
		//}		
	}
    

    // Check WP version.
	private function fwdevp_check_wp_ver(){
	    global $wp_version;
	    
		$exit_msg = "The Easy Video Player plugin requires WordPress " . esc_html(FWDEVP::MIN_WP_VER) . " or newer. <a href='http://codex.wordpress.org/Updating_WordPress'>Please update!</a>";
		
		if (version_compare($wp_version, FWDEVP::MIN_WP_VER) <= 0){
			echo $exit_msg;
			return false;
		}
		return true;
	}
	

	// Set CSS editor.
	public function fwdevp_set_css_editor(){
    	if (!$this->fwdevp_check_wp_ver()){
    		return;
    	}
    	
    	$msg = "";
    	$scroll_pos = 0;
    	
    	$css_file = plugin_dir_path(dirname(__FILE__)) . "css/fwdevp.css";
    	
	    if (!empty($_POST) && check_admin_referer("fwdevp_css_editor_update", "fwdevp_css_editor_nonce")){
			$handle = fopen($css_file, "w") or die("Cannot open file: " . $css_file);
			
			$data = str_replace("\\", "", $_POST["css_data"]);
			$data = str_replace("'e", "'\\e", $data);
			
			fwrite($handle, $data);
			
			$msg = __("The CSS file has been updated!", 'fwdevp');
		}
		
		$handle = fopen($css_file, "r") or die("Cannot open file: " . $css_file);
    	include_once "css_editor.php";
    	fclose($handle);
    }

	
	// Set general settings.
    public function fwdevp_set_general_settings(){
		
    	if (!$this->fwdevp_check_wp_ver()){
    		return;
    	}
    	
    	$msg = "";
    	
    	$set_id = 0;
		$set_order_id = 0;
		$tab_init_id = 0;
		$tootlTipImgSrc = esc_url_raw($this->_dir_url) . "content/icons/help-icon.png"; 
		$iconsPath = esc_url_raw($this->_dir_url) . "content/icons/";
    	
	    if (!empty($_POST) && check_admin_referer("fwdevp_general_settings_update", "fwdevp_general_settings_nonce")){
			$data_obj = json_decode(str_replace("\\", "", $_POST["settings_data"]), true);
			$action = $data_obj["action"];
			$settingsAr = $data_obj["settings_ar"];
			$videoStartBehaviour = $data_obj["fwdevpVideoStartBehaviour"];
			$keepCookies = $data_obj["fwdevpKeepCookies"];
			$replaceDF = $data_obj["fwdevpReplaceDF"];
			$replaceDFSkin = $data_obj["fwdevpReplaceDFSkin"];
			
			// Validate input.
			foreach ($settingsAr as $key => $value) {
				
				if(!empty($settingsAr[$key]["autoPlayText"])){
					$settingsAr[$key]["autoPlayText"] = sanitize_text_field($settingsAr[$key]["autoPlayText"]);
				}

				if(!empty($settingsAr[$key]["googleAnalyticsTrackingCode"])){
					$settingsAr[$key]["googleAnalyticsTrackingCode"] = sanitize_text_field($settingsAr[$key]["googleAnalyticsTrackingCode"]);
				}
				
				if(!empty($settingsAr[$key]["privateVideoPassword"])){
					$settingsAr[$key]["privateVideoPassword"] = sanitize_text_field($settingsAr[$key]["privateVideoPassword"]);
				}
				
				if(!empty($settingsAr[$key]["loggedInMessage"])){
					$settingsAr[$key]["loggedInMessage"] = esc_html($settingsAr[$key]["loggedInMessage"]);
				}
			
				if(!empty($settingsAr[$key]["logo_link"])){
					$settingsAr[$key]["logo_link"] = sanitize_text_field($settingsAr[$key]["logo_link"]);
				}
				if(!empty($settingsAr[$key]["logo_path"])){
					$settingsAr[$key]["logo_path"] = sanitize_text_field($settingsAr[$key]["logo_path"]);
				}
				if(!empty($settingsAr[$key]["skip_to_video_text"])){
					$settingsAr[$key]["skip_to_video_text"] = sanitize_text_field($settingsAr[$key]["skip_to_video_text"]);
				}
				if(!empty($settingsAr[$key]["skip_to_video_button_text"])){
					$settingsAr[$key]["skip_to_video_button_text"] = sanitize_text_field($settingsAr[$key]["skip_to_video_button_text"]);
				}
				if(!empty($settingsAr[$key]["aopwTitle"])){
					$settingsAr[$key]["aopwTitle"] = sanitize_text_field($settingsAr[$key]["aopwTitle"]);
				}
				if(!empty($settingsAr[$key]["mainBackgroundImagePath"])){
					$settingsAr[$key]["mainBackgroundImagePath"] = sanitize_text_field($settingsAr[$key]["mainBackgroundImagePath"]);
				}
			}
			
			$this->_data->videoStartBehaviour = $videoStartBehaviour;
			$this->_data->keepCookies = $keepCookies;
			$this->_data->replaceDF = $replaceDF;
			$this->_data->replaceDFSkin = $replaceDFSkin;
			$this->_data->settings_ar = $settingsAr;
			
			$this->_data->set_data();
			switch ($action){
			    case "add":
			        $msg = esc_html__("Your new preset has been added!", 'fwdevp');
			        $set_id = $data_obj["set_id"];
					$set_order_id = $data_obj["set_order_id"];
					$tab_init_id = $data_obj["tab_init_id"];
			        break;
			    case "save":
			        $msg = esc_html__("Your preset settings have been updated!", 'fwdevp');
			        $set_id = $data_obj["set_id"];
					$set_order_id = $data_obj["set_order_id"];
					$tab_init_id = $data_obj["tab_init_id"];
			        break;
			    case "del":
			       	$msg = esc_html__("Your preset has been deleted!", 'fwdevp');
			        break;
			}
		}
	
        // Add and escape required js vars.
        $vars = 'var fwdevpSettingsAr = ' . '"' . esc_html(json_encode($this->_data->settings_ar)) . '";';
        $vars .= 'var fwdevpVideoStartBehaviour = ' . '"' . esc_html(json_encode($this->_data->videoStartBehaviour)) . '";';
        $vars .= 'var fwdevpTextDomain = ' . '"' . esc_html(FWDEVP_TEXT_DOMAIN) . '";';
        $vars .= 'var fwdevpKeepCookies = ' . '"' . esc_html(json_encode($this->_data->keepCookies)) . '";';
        $vars .= 'var fwdevpReplaceDF = ' . '"' . esc_html(json_encode($this->_data->replaceDF)) . '";';
        $vars .= 'var fwdevpReplaceDFSkin = ' . '"' . esc_html(json_encode($this->_data->replaceDFSkin)) . '";';
        $vars .= 'var fwdevpSpacesUrl = ' . '"' . esc_url_raw($this->_dir_url) . "content/spaces/" . '";';
        $vars .= 'var fwdevpIconsPath = ' . '"' . esc_url_raw($this->_dir_url) . "content/icons/" . '";';
        $vars .= 'var fwdevpSetId = ' .  esc_html($set_id) .';';
    	$vars .= 'var fwdevpCurOrderId = ' .  esc_html($set_order_id) .';';
    	$vars .= 'var fwdevpTabInitId = ' . esc_html($tab_init_id) .';';
        wp_add_inline_script('fwdevp_general_settings', $vars);

    	include_once "general_settings.php";
    }
    

    // Set action links.
	public static function fwdevp_set_action_links($links){
		$settings_link = "<a href='" . get_admin_url(null, "admin.php?page=fwdevp-menu-general-settings") . "'>Settings</a>";
   		array_unshift($links, $settings_link);
   		
   		return $links;
	}
	

	// Check if user is logged in.
	public function fwdevp_is_user_logged_in() {
		$user = wp_get_current_user();
		return $user->exists();
	}
    

    // Get constructor.
    public function fwdevp_get_constructor($preset, $video_path, $poster_path, $video_ad_path, $ads_thumb_path, $subtitle_path, $popup_ads, $playback_rate_speed, $start_at_video, $start_at_subtitle, $advertisement_on_pause_source, $cuepoints, $start_at_time, $stop_at_time, $vast, $redirect_url, $redirect_target, $thumbnails_preview, $replace_default_video){
	
    	$preset = $preset;
    	
		// Video obejct.
		$videoString = "";
		if(strpos($video_path, "{source") === false){
			$videoString = "[{source:'" . $video_path . "', label:''}]" ;
		}else{
			$videoString = "[" . $video_path . "]";
		}
		
		// Display type.
		$displayType = "";
		if(strpos($video_path, "backgroundVideo") === false){
			$displayType = $preset['display_type'];
		}else{
			$displayType = "backgroundVideo";
		}
		
		// Subtitle obejct.
		$subtitleString = NULL;
		if(strpos($subtitle_path, "{source") === false){
			$subtitleString = "[{source:'" . $subtitle_path . "', label:''}]" ;
		}else {
			$subtitleString = "[" . $subtitle_path . "]";
		}

		$subtitleString = str_replace('source', 'subtitlePath', $subtitleString);
		$subtitleString = str_replace('label', 'subtileLabel', $subtitleString);
		if(empty($subtitle_path))  $subtitleString = '';
	
		// Popup obejct.
		$popupadString = "[]";
		if(strpos($popup_ads, "{source") !== false || strpos($popup_ads, "{google_ad_client") !== false){
			$popupadString = "[" . $popup_ads . "]";
		}else if(strpos($popup_ads, "{source") !== false){
			$popupadString = "[]";
		}
		
		$popupadString = str_replace('google_ad_start_time', 'timeStart', $popupadString);
		$popupadString = str_replace('google_ad_stop_time', 'timeEnd', $popupadString);
		$popupadString = str_replace('source', 'imagePath', $popupadString);
		$popupadString = str_replace('url', 'link', $popupadString);
		$popupadString = str_replace('start_time', 'timeStart', $popupadString);
		$popupadString = str_replace('stop_time', 'timeEnd', $popupadString);

		// Vast obejct.
		$vastURL = "";
		$vastTarget = "_blank";
		$vastStartTime = "00:00:00";

		if(strpos($vast, "{source") !== false){
			preg_match('/source:\'(.*?)\'/', $vast, $vastSourceRG);
			$vastURL = $vastSourceRG[1];
		}
	
		// Cupoints object.
		$cupointString = "[]";
		if(strpos($cuepoints, "{timeStart") !== false){
			$cupointString = "[" . $cuepoints . "]";
		}else if(strpos($cuepoints, "{timeStart") !== false){
			$cupointString = "[]";
		}
		
		// Popup obejct.
		$videoadString = "[]";
		if(strpos($video_ad_path, "{source") !== false){
			$videoadString = "[" . $video_ad_path . "]";
		}else if(strpos($video_ad_path, "{source") !== false){
			$videoadString = "[]";
		}
		$videoadString = str_replace('url', 'link', $videoadString);
		$videoadString = str_replace('start_time', 'timeStart', $videoadString);
		$videoadString = str_replace('fwdevp_add_duration', 'addDuration', $videoadString);
		$videoadString = str_replace('fwdevp_time_to_hold_add', 'timeToHoldAds', $videoadString);

		$checkLegthOfVideos = count((explode('},', $videoString)));
		if(is_numeric($start_at_video)){
			if($start_at_video > $checkLegthOfVideos){
				$start_at_video = $checkLegthOfVideos - 1;
			}else{
				$start_at_video = max(0, $start_at_video - 1);
			}
		}else{
			$start_at_video = 0;
		}
	
		if(strlen($subtitle_path) > 0){
			$checkLegthOfSubtitles = count((explode('},', $subtitleString)));
			if(is_numeric($start_at_subtitle)){
				if($start_at_subtitle > $checkLegthOfSubtitles){
					$start_at_subtitle = $checkLegthOfSubtitles;
				}else{
					$start_at_subtitle = max(0, $start_at_subtitle);
				}
			}else{
				$start_at_subtitle = 0;
			}
		}else{
			$start_at_subtitle = 0;
		}
		
		$isLoggedIn = $this->fwdevp_is_user_logged_in();
		if($isLoggedIn ==  true){
			$isLoggedIn = "yes";
		}else{
			$isLoggedIn = "no";
		}
		

		$preloaderColors = "['" . esc_html($preset['preloaderColor1']) . "','" . esc_html($preset['preloaderColor2']) . "']";

		/**
    	  *  Minified constructor to optimize page loading and also make sure it works
    	  *  in all themes, even those with wired plugins/code that tries to modify scripts
    	  *  and other unexpected bad code...
    	  */
    	$output =  "document.addEventListener('DOMContentLoaded', function(){if(document.getElementById('fwdevpDiv" . esc_html(FWDEVP::$_evp_id) . "')){loadEVP" . esc_html(FWDEVP::$_evp_id) . "();}});function loadEVP" . esc_html(FWDEVP::$_evp_id) . "(){FWDEVPlayer.videoStartBehaviour = '" . esc_html($this->_data->videoStartBehaviour) . "';FWDEVPUtils.checkIfHasTransofrms(); new FWDEVPlayer({" . "instanceName:'fwdevpPlayer" . esc_html(FWDEVP::$_evp_id) . "',initializeOnlyWhenVisible:'" . esc_html($preset['initializeOnlyWhenVisible']) . "',openDownloadLinkOnMobile:'" . esc_html($preset['openDownloadLinkOnMobile']) . "',preloaderBackgroundColor:'" . esc_html($preset['preloaderColor1']) . "',preloaderFillColor:'" . esc_html($preset['preloaderColor2']) . "',fillEntireVideoScreen:'" . esc_html($preset['fill_entire_video_screen']) . "',useHEXColorsForSkin:'" . esc_html($preset['use_HEX_colors_for_skin']) . "',showYoutubeRelAndInfo:'" . esc_html($preset['showYoutubeRelAndInfo']) . "',stickyOnScroll:'" . esc_html($preset['stickyOnScroll']) . "',stickyOnScrollShowOpener:'" . esc_html($preset['stickyOnScrollShowOpener']) . "',contextMenuType:'" .  esc_html($preset['contextMenuType']) . "',showScriptDeveloper:'" .  esc_html($preset['showScriptDeveloper']) . "',contextMenuBackgroundColor:'" .  esc_html($preset['contextMenuBackgroundColor']) . "',contextMenuBorderColor:'" .  esc_html($preset['contextMenuBorderColor']) . "',contextMenuSpacerColor:'" .  esc_html($preset['contextMenuSpacerColor']) . "',contextMenuItemNormalColor:'" .  esc_html($preset['contextMenuItemNormalColor']) . "',contextMenuItemSelectedColor:'" .  esc_html($preset['contextMenuItemSelectedColor']) . "',contextMenuItemDisabledColor:'" .  esc_html($preset['contextMenuItemDisabledColor']) . "',stickyOnScrollWidth:" . esc_html($preset['stickyOnScrollWidth']) . ",stickyOnScrollHeight:" . esc_html($preset['stickyOnScrollHeight']) . ",showDefaultControllerForVimeo:'" . esc_html($preset['showDefaultControllerForVimeo']) . "',normalHEXButtonsColor:'" . esc_html($preset['normal_HEX_buttons_color']) . "',parentId:'fwdevpDiv" . esc_html(FWDEVP::$_evp_id) . "',mainFolderPath:'" . esc_url_raw($this->_dir_url) . "content',videoSource:" . html_entity_decode(esc_html($videoString), ENT_QUOTES) . ",startAtVideoSource:" .  esc_html($start_at_video)  . ", useVectorIcons:'" .  esc_html($preset['useFontAwesomeIcons']) .  "' ,startAtTime:'" .  esc_html($start_at_time) . "',stopAtTime:'" .  esc_html($stop_at_time) . "',popupCommercialAdsSource:" . html_entity_decode(esc_html($popupadString), ENT_QUOTES) . ",privateVideoPassword:'" . esc_html(md5($preset['privateVideoPassword'])) . "',posterPath:'" . esc_url_raw($poster_path) . "'," . "skinPath:'" . esc_html($preset['skin_path']) . "',aopwSource:'" . html_entity_decode(esc_html($advertisement_on_pause_source)) . "',aopwTitle:'" . esc_html($preset['aopwTitle']) . "',aopwWidth:" . esc_html($preset['aopwWidth']) . ",aopwHeight:" . esc_html($preset['aopwHeight']) . ",aopwBorderSize:" . esc_html($preset['aopwBorderSize']) . ",useResumeOnPlay:'" . esc_html($preset['use_resume_on_play'])  . "',redirectURL:'" .  html_entity_decode(esc_html($redirect_url))  . "',redirectTarget:'" . esc_html($redirect_target) . "',googleAnalyticsTrackingCode:'" . esc_html($preset['googleAnalyticsTrackingCode']) . "',aopwTitleColor:'" . esc_html($preset['aopwTitleColor']) . "',showErrorInfo:'" . esc_html($preset['showErrorInfo']) . "',playsinline:'" . esc_html($preset['playsinline']) . "',displayType:'" . esc_html($displayType) . "',disableDoubleClickFullscreen:'" . esc_html($preset['disableDoubleClickFullscreen']) . "',executeCuepointsOnlyOnce:'" . esc_html($preset['executeCuepointsOnlyOnce']) . "',showPreloader:'" . esc_html($preset['showPreloader']) . "',show360DegreeVideoVrButton:'" .  esc_html($preset['show360DegreeVideoVrButton']) . "',addKeyboardSupport:'" . esc_html($preset['add_keyboard_support']) . "',autoScale:'" . esc_html($preset['auto_scale']) . "',autoPlay:'" . esc_html($preset['autoplay']) . "',autoPlayText:'" . esc_html($preset['autoPlayText']) . "',loop:'" . esc_html($preset['loop']) . "',maxWidth:" . esc_html($preset['max_width']) . ",maxHeight:" . esc_html($preset['max_height']) . ",volume:" . esc_html($preset['volume']) . ",audioVisualizerLinesColor:'" . esc_html($preset['audioVisualizerLinesColor']) . "',audioVisualizerCircleColor:'" . esc_html($preset['audioVisualizerCircleColor']) . "',isLoggedIn:'" . esc_html($isLoggedIn) . "',goFullScreenOnButtonPlay:'" .  esc_html($preset['goFullScreenOnButtonPlay']) . "',playVideoOnlyWhenLoggedIn:'" .  esc_html($preset['playVideoOnlyWhenLoggedIn']) . "',loggedInMessage:\"" .  html_entity_decode(esc_html($preset['loggedInMessage'], ENT_QUOTES)) . "\",backgroundColor:'" . esc_html($preset['bg_color']) . "',fillEntireScreenWithPoster:'" . esc_html($preset['fillEntireScreenWithPoster']) . "',showSubtitleButton:'" . esc_html($preset['show_subtitle_button']) . "',subtitlesOffLabel:'" . esc_html($preset['subtitles_off_label']) . "',startAtSubtitle:" . esc_html($start_at_subtitle) . ",posterBackgroundColor:'" . esc_html($preset['poster_bg_color']) . "'," . "showControllerWhenVideoIsStopped:'" . esc_html($preset['show_controller_when_video_is_stopped']) . "',show360DegreeVideoVrButton:'" . esc_html($preset['show360DegreeVideoVrButton']) . "',showController:'" . esc_html($preset['show_controller']) . "',useChromeless:'" . esc_html($preset['use_chromeless']) . "',showPlaybackRateButton:'" . esc_html($preset['showPlaybackRateButton']) . "',defaultPlaybackRate:" . esc_html($playback_rate_speed) . ",showScrubberWhenControllerIsHidden:'" . esc_html($preset['showScrubberWhenControllerIsHidden']) . "',useWithoutVideoScreen:'" . esc_html($preset['useWithoutVideoScreen']) . "',showVolumeScrubber:'" . esc_html($preset['show_volume_scrubber']) . "',showVolumeButton:'" . esc_html($preset['show_volume_button']) . "',showTime:'" . esc_html($preset['show_time']) . "',showQualityButton:'" . esc_html($preset['show_youtube_quality_button']) . "',showShareButton:'" . esc_html($preset['show_share_button']) . "',showDownloadButton:'" . esc_html($preset['show_download_button']) . "',showChromecastButton:'" . esc_html($preset['showChromecastButton']) . "',showEmbedButton:'" . esc_html($preset['show_embed_button'])  . "',showRewindButton:'" . esc_html($preset['showRewindButton']) . "',showFullScreenButton:'" . esc_html($preset['show_fullscreen_button']) . "',repeatBackground:'" . esc_html($preset['repeat_background']) . "',controllerHeight:" . esc_html($preset['controller_height']) . ",controllerHideDelay:" . esc_html($preset['controller_hide_delay']) . ",startSpaceBetweenButtons:" . esc_html($preset['start_space_between_buttons']) . ",spaceBetweenButtons:" . esc_html($preset['space_between_buttons']) . ",scrubbersOffsetWidth:" . esc_html($preset['scrubbers_offset_width']) . ",mainScrubberOffestTop:" . esc_html($preset['main_scrubber_offest_top']) . ",timeOffsetLeftWidth:" . esc_html($preset['time_offset_left_width']) . ",timeOffsetRightWidth:" . esc_html($preset['time_offset_right_width']) . ",volumeScrubberWidth:" . esc_html($preset['volume_scrubber_width']) . ",volumeScrubberOffsetRightWidth:" . esc_html($preset['volume_scrubber_offset_right_width']) . ",timeColor:'" . esc_html($preset['time_color']) . "',youtubeQualityButtonNormalColor:'" . esc_html($preset['youtube_quality_button_normal_color']) . "',showPopupAdsCloseButton:'" . esc_html($preset['show_popup_ads_close_button']) . "',youtubeQualityButtonSelectedColor:'" . esc_html($preset['youtube_quality_button_selected_color']) . "'," . "showLogo:'" . esc_html($preset['show_logo']) . "',hideLogoWithController:'" . esc_html($preset['hide_logo_with_controller']) . "',logoPosition:'" . esc_html($preset['logo_position']) . "',logoPath:'" . esc_html($preset['logo_path']) . "',logoLink:'" . esc_html($preset['logo_link']) . "',cuepoints:" . html_entity_decode(esc_html($cupointString), ENT_QUOTES) . ",  logoMargins:" . esc_html($preset['logo_margins']) . "," . "vastSource:'" . html_entity_decode(esc_html($vastURL), ENT_QUOTES) . "',vastLinearStartTime:'" . esc_html($vastStartTime) . "',vastClickTroughTarget:'" . esc_html($vastTarget) . "'," ."embedWindowCloseButtonMargins:" . esc_html($preset['embed_and_info_window_close_button_margins']) . ",borderColor:'" . esc_html($preset['border_color']) . "',mainLabelsColor:'" . esc_html($preset['main_labels_color'])  . "', closeLightBoxWhenPlayComplete:'" . esc_html($preset['closeLightBoxWhenPlayComplete']) .  "',lightBoxBackgroundColor:'" . esc_html($preset['lightBoxBackgroundColor']) . "',lightBoxBackgroundOpacity:" . esc_html($preset['lightBoxBackgroundOpacity']) . ",secondaryLabelsColor:'" . esc_html($preset['secondary_labels_color']) . "',showOpener:'" . esc_html($preset['showOpener']) . "',verticalPosition:'" . esc_html($preset['verticalPosition']) . "',horizontalPosition:'" . esc_html($preset['horizontalPosition']) . "',showPlayerByDefault:'" . esc_html($preset['showPlayerByDefault']) . "',animatePlayer:'" . esc_html($preset['animatePlayer']) . "',showOpenerPlayPauseButton:'" . esc_html($preset['showOpenerPlayPauseButton'])	 . "',openerAlignment:'" . esc_html($preset['openerAlignment']) . "',mainBackgroundImagePath:'" . esc_html($preset['mainBackgroundImagePath']) . "',openerEqulizerOffsetTop:" . esc_html($preset['openerEqulizerOffsetTop']) . ",openerEqulizerOffsetLeft:" . esc_html($preset['openerEqulizerOffsetLeft']) . ",offsetX:" . esc_html($preset['offsetX']) . ",offsetY:" . esc_html($preset['offsetY']) . ",shareAndEmbedTextColor:'" . esc_html($preset['share_and_embed_text_color']) . "',inputBackgroundColor:'" . esc_html($preset['input_background_color']) . "',inputColor:'" . esc_html($preset['input_color']) . "'," ."openNewPageAtTheEndOfTheAds:'" . esc_html($preset['open_new_page_at_the_end_of_the_ads']) . "',adsSource:" . html_entity_decode(esc_html($videoadString), ENT_QUOTES) . ",adsButtonsPosition:'" . esc_html($preset['ads_buttons_position']) . "',skipToVideoText:'" . esc_html($preset['skip_to_video_text']) . "',skipToVideoButtonText:'" . esc_html($preset['skip_to_video_button_text']) . "',showMainScrubberToolTipLabel:'" . esc_html($preset['showMainScrubberToolTipLabel']) . "',scrubbersToolTipLabelFontColor:'" . esc_html($preset['scrubbersToolTipLabelFontColor']) .  "',scrubbersToolTipLabelBackgroundColor:'" . esc_html($preset['scrubbersToolTipLabelBackgroundColor']) . "',useAToB:'" . esc_html($preset['useAToB']) . "',atbTimeBackgroundColor:'" . esc_html($preset['atbTimeBackgroundColor']) . "',atbTimeTextColorNormal:'" . esc_html($preset['atbTimeTextColorNormal']) . "',atbTimeTextColorSelected:'" . esc_html($preset['atbTimeTextColorSelected']) . "',atbButtonTextNormalColor:'" . esc_html($preset['atbButtonTextNormalColor']) . "',atbButtonTextSelectedColor:'" . esc_html($preset['atbButtonTextSelectedColor']) . "',atbButtonBackgroundNormalColor:'" . esc_html($preset['atbButtonBackgroundNormalColor']) . "',atbButtonBackgroundSelectedColor:'" . esc_html($preset['atbButtonBackgroundSelectedColor'])  . "',adsTextNormalColor:'" . esc_html($preset['ads_text_normal_color']) . "',thumbnailsPreview:'" . html_entity_decode(esc_html($thumbnails_preview), ENT_QUOTES) . "',thumbnailsPreviewWidth:" . esc_html($preset['thumbnails_preview_width']) . ",thumbnailsPreviewHeight:" . esc_html($preset['thumbnails_preview_height']) . ",thumbnailsPreviewBackgroundColor:'" . esc_html($preset['thumbnails_preview_background_color']) . "',thumbnailsPreviewBorderColor:'" . esc_html($preset['thumbnails_preview_border_color']) . "',thumbnailsPreviewLabelBackgroundColor:'" . esc_html($preset['thumbnails_preview_label_background_color']) . "',thumbnailsPreviewLabelFontColor:'" . esc_html($preset['thumbnails_preview_label_font_color']) . "',adsTextSelectedColor:'" . esc_html($preset['ads_text_selected_color']) . "',adsBorderNormalColor:'" . esc_html($preset['ads_border_normal_color']) . "',adsBorderSelectedColor:'" . esc_html($preset['ads_border_selected_color']) . "'"; if($subtitleString != NULL){$output .= ", subtitlesSource:" . html_entity_decode(esc_html($subtitleString), ENT_QUOTES) . "";}$output .= "})";$output .= "}";

    		return $output;
    }


    /**
	  * Lightbox shortcode.
	  * Ex: [fwdevp-lightbox instanceName="fwdevpPlayer0" opener="" auto_open=""]Open player in lightbox[/fwdevp-lightbox]
	  */
	public function fwdevp_shortcode_lightbox($args = null, $content = null) {
		extract(shortcode_atts(array('opener'=>"", 'auto_open'=>''), $args, "fwdevp-lightbox"));
		
		$output= '';
		if(!empty($opener)){
			$output .= 'var $=jQuery; setTimeout(function(){ $("' . esc_html($opener) . '").on("click", function(){' . esc_html($args['instancename']) . '.showLightbox();})}, 100);';
		}else{
			$output  .= '<button type="button" onclick="' . esc_html($args['instancename']) . '.showLightbox()">';
			$output .= esc_html($content);
			$output .= '</button>';
			return $output; // All dynamic content has been escaped.
		}
	
		if(!empty($auto_open)){
			$output .= 'setTimeout(function(){ ' . esc_html($args['instancename']) . '.showLightbox();}, 500);';
		}

		wp_register_script( 'fwdevp-dummy-handle-footer', '', [], '', true );
   		wp_enqueue_script( 'fwdevp-dummy-handle-footer'  );
    	wp_add_inline_script( 'fwdevp-dummy-handle-footer', $output ); // All dynamic content has been escaped.
	}


	// Set player/shortcode.
 	public function fwdevp_set_player($atts){
		extract(shortcode_atts(array("preset_id" => "", "video_path" => "",  "start_at_time" => "",  "stop_at_time" => "", "poster_path" => "", "video_ad_path" => "", "subtitle_path" => "", "ads_thumb_path" => "", "popup_ads" => "", "playback_rate_speed" => "", "start_at_video" => "", "start_at_subtitle" => "", "advertisement_on_pause_source" => "" , "cuepoints" => "" , "vast" => "", "redirect_url" => "", "redirect_target" => "", "thumbnails_preview" => "", "replace_default_video" => false), $atts, "fwdevp"));
		
		// Check preset.
		$preset = null;
		foreach ($this->_data->settings_ar as $set){
    		if ($set["name"] == $preset_id){
    			$preset = $set;
    		}
    	}

		if (is_null($preset)){
    		return "Preset with id <strong>". esc_html($preset_id) . "</strong> does not exist!";
    	}

		if(empty($playback_rate_speed)){
			$playback_rate_speed = 1;
		}
		
		$evp_constructor = $this->fwdevp_get_constructor($preset, $video_path, $poster_path, $video_ad_path, $ads_thumb_path, $subtitle_path, $popup_ads, $playback_rate_speed, $start_at_video, $start_at_subtitle, $advertisement_on_pause_source, $cuepoints, $start_at_time, $stop_at_time, $vast, $redirect_url, $redirect_target, $thumbnails_preview, $replace_default_video);
	
		$evp_div = "<div id='fwdevpDiv" . esc_html(FWDEVP::$_evp_id) . "'></div>";
		FWDEVP::$_evp_id++;
		$evp_output = $evp_div;

		wp_register_script( 'fwdevp-dummy-handle-footer', '', [], '', true );
   		wp_enqueue_script( 'fwdevp-dummy-handle-footer'  );
    	wp_add_inline_script( 'fwdevp-dummy-handle-footer', $evp_constructor );

		return $evp_output; // All dynamic content has been escaped.
	}


	// Shortcode generator metabox.
	public function fwdevp_set_custom_meta_box($post){
		if (!$this->fwdevp_check_wp_ver()){
    		return;
    	}
		// presets
		$presetsNames = array();
		$keepCookies = $this->_data->keepCookies;
		$tootlTipImgSrc = esc_url_raw($this->_dir_url) . "content/icons/help-icon.png"; 

		foreach ($this->_data->settings_ar as $setting){
    		$el = array(
    						"id" => $setting["id"],
    						"name" => $setting["name"]
    				   );
    				   
    		array_push($presetsNames, $el);
    	}
		
        // Add and escape required js vars.
        $vars = 'var fwdevpPresetsObj = ' . '"' . esc_html(json_encode($presetsNames)) . '";';
        $vars .= 'var fwdevpKeepCookies = ' . '"' . esc_html(json_encode($keepCookies)) . '";';
        $vars .= 'var fwdevpAdd__ = ' . '"' . esc_html__('Add', 'fwdevp')  . '"' . ';';
    	$vars .= 'var fwdevpCancel__ = ' . '"' . esc_html__('Cancel', 'fwdevp') . '"' . ';';
        wp_add_inline_script('fwdevp_shortcode', $vars);

    	include_once "meta_box.php";
	}


	// Replace deafult WP player.
	private function fwdevp_replace_wp_default_player(){
		if($this->_data->replaceDF == "yes"){
			add_filter('render_block', array($this, "fwdevp_wrap_my_image_block"), 0, 2);
			add_filter('the_content', array($this,'fwdevp_disable_wp_auto_paragraph'), 1 );
			add_filter('wp_fwdevp_video_shortcode_override', array($this, 'fwdevp_video_shortcode_override'), 10, 2);
			add_filter('embed_oembed_html', array($this, 'fwdevp_wrap_oembed_html'), 99, 4);
			add_filter('video_embed_html', array($this, 'fwdevp_wrap_oembed_html'), 99);
		}
	}

	public function fwdevp_disable_wp_auto_paragraph($content){
	    remove_filter('the_content', 'wpautop');
	    remove_filter('the_excerpt', 'wpautop');
	    return $content;
	}

	public function fwdevp_wrap_my_image_block($block_content, $block) {
		$found = false;
		$skin = $this->_data->replaceDFSkin;

		foreach($this->_data->settings_ar as $key) {
			if($key['name'] == $skin){
				$found = true;
				break;
			}
		}

		if(!$found){
			$skin = $this->_data->settings_ar[0]['name'];
		}
		
		if('core/video' == $block['blockName']){
			preg_match("/<video.*src=\"(.*)\"/", $block_content, $matches);
			$video_url = $matches[1];
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$video_url));
		}else if('core-embed/youtube' == $block['blockName']){
			preg_match('/videoSource:\[\{source:\'(.*?)\'/', $block_content, $matches);
			$video_url = $matches[1];
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$video_url));
		}else if('core-embed/vimeo' == $block['blockName']){
			preg_match('/videoSource:\[\{source:\'(.*?)\'/', $block_content, $matches);
			$video_url = $matches[1];
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$video_url));
		}else{
			return $block_content;
		}
	}
	
	public function fwdevp_video_shortcode_override($html, $attr){
		$found = false;
		$skin = $this->_data->replaceDFSkin;

		foreach($this->_data->settings_ar as $key) {
			if($key['name'] == $skin){
				$found = true;
				break;
			}
		}

		if(!$found){
			$skin = $this->_data->settings_ar[0]['name'];
		}
		if(isset($attr['mp4'])){
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$attr['mp4']));
	    }else{
	        return "";
	    }
	}

	public function fwdevp_wrap_oembed_html($cache, $url, $attr, $post_ID){
		
		$found = false;
		$skin = $this->_data->replaceDFSkin;

		foreach($this->_data->settings_ar as $key) {
			if($key['name'] == $skin){
				$found = true;
				break;
			}
		}

		if(!$found){
			$skin = $this->_data->settings_ar[0]['name'];
		}
	
		if(false !== strpos($url, 'youtube.')){
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$url, 'replace_default_video'=>true));
		}else if (false !== strpos($url, 'vimeo.')) {
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$url, 'replace_default_video'=>true));
		}else if (false !== strpos($url, '.mp4')) {
			return $this->fwdevp_set_player(array('preset_id'=>$skin, 'video_path'=>$url, 'replace_default_video'=>true));
		}else{
			return $cache;
		}
	}
		
}
?>