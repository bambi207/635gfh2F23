<form class="fwdevp" action="" method="post">
	<div class="ui-widget ui-widget-content ui-corner-all">
		<label for="css_text"><?php esc_html_e('Here you can edit the player main CSS file (css/fwdevp.css):', 'fwdevp'); ?></label>
	  	<br><br>
	  	<textarea id="css_text" cols="256" rows="32"><?php echo fread($handle, filesize($css_file)); ?></textarea>
  	</div>
  	
  	<input type="hidden" id="css_data" name="css_data" value="">
  	<input type="hidden" id="scroll_pos" name="scroll_pos" value="<?php echo esc_html($scroll_pos); ?>">

	<input id="update_btn" type="submit" name="submit" value="Update CSS file" />
	
	<?php wp_nonce_field("fwdevp_css_editor_update", "fwdevp_css_editor_nonce"); ?>
</form>

<?php if(!(empty($msg))): ?>
<div class='fwd-updated'>
	<p class="fwd-updated-p">
		<?php echo esc_html($msg); ?>
	</p>
</div>
<?php endif; ?>