<!-- Cuepoint dialog. -->
<div id="fwd-evp-ccreate-cuepoint-dialog" title="<?php esc_html_e('Add new cuepoint', 'fwdevp'); ?>">
	<p id="fwdevp_cuepoint_tips"><?php esc_html_e('The start time field is required.', 'fwdevp'); ?></p>
	<table class="fwdevp-dialog">
		<tr>
			<td>
				<label for="fwdevp_cuepoint_start_time"><?php esc_html_e('Start time:', 'fwdevp'); ?></label>
			</td>
			<td>
				<input type="text" id="fwdevp_cuepoint_start_time" class="text ui-widget-content ui-corner-all">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The start time of for the cuepoint , the format is hours:minutes:seconds, for example 01:20:20.', 'fwdevp'); ?>"/>
			</td>
		</tr>
		<tr>
			<td>
				<label for="fwdevp_cuepoint_start_time"><?php esc_html_e('Cuepoint javascript code:', 'fwdevp'); ?></label>
			</td>
			<td >
				<input type="text" id="fwdevp_cuepoint_code" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></input>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The cupoint javascript function that will be executed at the cuepoint start time. If you have a javascript function defined in your page it can be set here to be called at the start time, for example if the function is called myFunction set this to myFunction(); make sure you add the parentheses as well.', 'fwdevp'); ?>">
			</td>
		</tr>
	</table>
</div>


<!-- Vast dialog. -->
<div id="fwdevp_add-vast-dialog" title="<?php esc_html_e('Add new VAST / VMAP / IMA  file', 'fwdevp'); ?>">
	<p id="fwdevp_add_vast_tips"><?php esc_html_e('The source URL field is required.', 'fwdevp'); ?></p>
	<table class="fwdevp-dialog">
		<tr>
			<td>
				<label for="fwdevp_vast_xml_url"><?php esc_html_e('Source:', 'fwdevp'); ?></label>
			</td>
			<td>
				<input type="text" id="fwdevp_vast_xml_url" onkeyup="fwdevp_adjustHeight(this);" class="text ui-widget-content ui-corner-all">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The absolute path of a valid VAST / VAMAP / GOOGLE IMA file.', 'fwdevp'); ?>"/>
			</td>
		</tr>
	</table>
</div>


<!-- Pre-roll,mid-roll,post-roll. -->
<div id="fwdevp_add-videoad-dialog" title="<?php esc_html_e('Add new pre-roll,mid-roll,post-roll advertisement', 'fwdevp'); ?>">

	<p id="fwdevp_add_videoad_tips"><?php esc_html_e('The source field is required.', 'fwdevp'); ?></p>

	<fieldset>
		<table class="fwdevp-dialog">
			<tr>
				<td>
					<label for="fwdevp_videoad_image_source"><?php esc_html_e('Video source:', 'fwdevp'); ?></label>
				</td>
				<td class="has-button">
					<input id="fwdevp_videoad_image_source" type="text" class="text ui-widget-content ui-corner-all">
					<button id="fwdevp_videoad_image_source_button"><?php esc_html_e('Add from media library', 'fwdevp'); ?></button>
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The video mp4 path, image path, web page URL(iframe) or Youtube video URL.', 'fwdevp'); ?>">
				</td>
			</tr>
			<tr class="empty-after-button"></tr>
			<tr>
				<td>
					<label for="fwdevp_videofwdevp_ad_url"><?php esc_html_e('URL:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_videofwdevp_ad_url" class="text ui-widget-content ui-corner-all">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The optional page URL to open when the video ad is clicked.', 'fwdevp'); ?>">
				</td>
			</tr>
			<tr>
				<td>
					<label for="fwdevp_videofwdevp_ad_target"><?php esc_html_e('Target:', 'fwdevp'); ?></label>
				</td>
				<td>
					<select id="fwdevp_videofwdevp_ad_target" class="ui-corner-all">
						<option value="_blank">_blank</option>
						<option value="_self">_self</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="fwdevp_videoad_start_time"><?php esc_html_e('Start time:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_videoad_start_time" class="text ui-widget-content ui-corner-all">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The start time of for when the popup image will show, the format is hours:minutes:seconds, for example 01:20:20.', 'fwdevp'); ?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="fwdevp_time_to_hold_ad"><?php esc_html_e('Time to hold add:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_time_to_hold_ad" class="text ui-widget-content ui-corner-all">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The duration in seconds until the skip button will appear, for example to show the skip add button after 10 seconds set this to 10. If you don\'t want the skip button just set this to 0.', 'fwdevp'); ?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="fwdevp_add_duration"><?php esc_html_e('Add duration:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_add_duration" class="text ui-widget-content ui-corner-all">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The add duration in hh:mm:ss format to hold the add if an image is used, for example to hold the image add form 20 seconds set this option to 00:00:20.', 'fwdevp'); ?>"/>
				</td>
			</tr>
		</table>
  	</fieldset>
</div>


<!-- Popup add dialog. -->
<div id="fwdevp_add-popupad-dialog" title="<?php esc_html_e('Add new popup ad', 'fwdevp'); ?>">

	<p id="fwdevp_add_pr_tips"><?php esc_html_e('The source field is required.', 'fwdevp'); ?></p>

	<fieldset>
		<table class="fwdevp-dialog">
			<tr>
				<td>
					<label for="popupad_type"><?php esc_html_e('Type:', 'fwdevp'); ?></label>
				</td>
				<td>
					<select id="popupad_type" class="ui-corner-all">
						<option value="image"><?php esc_html_e('Image', 'fwdevp'); ?></option>
						<option value="adsense"><?php esc_html_e('Google Adsense', 'fwdevp'); ?></option>
					</select>
				</td>
			</tr>
		</table>
		
		<table class="fwdevp-dialog" id="evp_image_source">
			<tr>
				<td>	
					<label for="fwdevp_popup_image_source"><?php esc_html_e('Image source:', 'fwdevp'); ?></label>
				</td>
				<td class="has-button">
					<input id="fwdevp_popup_image_source" type="text" class="text ui-widget-content ui-corner-all">
					<button id="fwdevp_upload_image_source_button"><?php esc_html_e('Add image', 'fwdevp'); ?></button>
					<img  src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The image path of the popup image that will appear over the video.', 'fwdevp'); ?>">
				</td>
			</tr>
			<tr class="empty-after-button"></tr>
			<tr>	
				<td>	
					<label for="fwdevp_ad_url"><?php esc_html_e('URL:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_ad_url" class="text ui-widget-content ui-corner-all">	
				</td>
			</tr>	
			<tr>	
				<td>	
					<label for="fwdevp_ad_target"><?php esc_html_e('Target:', 'fwdevp'); ?></label>
				</td>
				<td>
					<select id="fwdevp_ad_target" class="ui-corner-all">
						<option value="_blank">_blank</option>
						<option value="_self">_self</option>
					</select>
				</td>
			</tr>
			<tr>	
				<td>	
					<label for="fwdevp_popup_start_time"><?php esc_html_e('Start time:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_popup_start_time" class="text ui-widget-content ui-corner-all">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The start time of the popup ad when will hide, the format is hours:minutes:seconds, for example 01:10:20.', 'fwdevp'); ?>"/>
				</td>
			</tr>	
			<tr>	
				<td>	
					<label for="fwdevp_popup_stop_time"><?php esc_html_e('Stop time:', 'fwdevp'); ?></label>
				</td>
				<td>
					<input type="text" id="fwdevp_popup_stop_time" class="text ui-widget-content ui-corner-all">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The stop time of the popup ad when will hide, the format is hours:minutes:seconds, for example 01:22:10.', 'fwdevp'); ?>"/>
				</td>
			</tr>	
		</table>

		<div id="evp_adsense">
			<table class="fwdevp-dialog">
				<tr>
					<td >
						<label for="google_ad_client"><?php esc_html_e('Google adsense ad client code:', 'fwdevp'); ?></label>
					</td>
					<td >
						<input type="text" id="google_ad_client" class="text ui-widget-content ui-corner-all">
						<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The google ad client code, you can get this from the google adsense embed code.', 'fwdevp'); ?>"/>
					</td>
				</tr>
				<tr>
					<td>
						<label for="google_ad_slot"><?php esc_html_e('Google adsense ad slot code:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input type="text" id="google_ad_slot" class="text ui-widget-content ui-corner-all">
						<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The google ad slot code, you can get this from the google adsense embed code.', 'fwdevp'); ?>"/>
					</td>
				</tr>
				<tr>
					<td>
						<label for="google_ad_width"><?php esc_html_e('Google adsense ad width:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input type="text" id="google_ad_width" class="text ui-widget-content ui-corner-all">
						<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The google adsense ad width in px.', 'fwdevp'); ?>"/>
					</td>
				</tr>
				<tr>
					<td>
						<label for="google_ad_height"><?php esc_html_e('Google adsense ad height:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input type="text" id="google_ad_height" class="text ui-widget-content ui-corner-all">
						<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The google adsense ad height in px.', 'fwdevp'); ?>"/>
					</td>
				</tr>
				<tr>
					<td>
						<label for="google_ad_start_time"><?php esc_html_e('Google adsense ad start time:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input type="text" id="google_ad_start_time" class="text ui-widget-content ui-corner-all">
						<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The start time of the popup ad when will show, the format is hours:minutes:seconds, for example 01:10:20.', 'fwdevp'); ?>"/>
					</td>
				</tr>
				<tr>
					<td>
						<label for="google_ad_stop_time"><?php esc_html_e('Google adsense ad stop time:', 'fwdevp'); ?></label>
					</td>
					<td>
						<input type="text" id="google_ad_stop_time" class="text ui-widget-content ui-corner-all">
						<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The stop time of the popup ad when will hide, the format is hours:minutes:seconds, for example 01:20:20.', 'fwdevp'); ?>"/>
					</td>
				</tr>
			</table>
		</div>
  	</fieldset>
</div>


<!-- Add video dialog. -->
<div id="fwdevp-add-video-dialog" title="<?php esc_html_e('Add new video', 'fwdevp'); ?>">

	<p id="fwdevp_add-video-tips"><?php esc_html_e('The label field is required.', 'fwdevp'); ?></p>

	<table class="fwdevp-dialog">
		<tr>
			<td>
				<label for="fwdevp_videoType"><?php esc_html_e('Video type:', 'fwdevp'); ?></label>
			</td>
			<td>
				<select id="fwdevp_videoType" class="ui-corner-all">
					<option value="normal"><?php esc_html_e('Normal video', 'fwdevp'); ?></option>
					<option value="360DegreeVideo"><?php esc_html_e('360 degrees / VR video', 'fwdevp'); ?></option>
					<option value="backgroundVideo"><?php esc_html_e('Background video', 'fwdevp'); ?></option>
					<option value="greenScreenVideo"><?php esc_html_e('Green screen video', 'fwdevp'); ?></option>
					<option value="hlsLiveStream"><?php esc_html_e('HLS live streaming', 'fwdevp'); ?></option>
				</select>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If 360 degrees / VR videos are used set this option to 360 degrees / VR video and if you want to enable VR in your preset set Show 360 degree VR button to yes. If you want to use it as a video background set this to background video, for green screen videos set this to green screen video. If you have an HLS live stream video and you want to show a live icon, disable the scrubber and show only the current time set this option to HLS live streaming, for all other video types (youtube, vimeo, HLS, mp4, google drive etc.) or audio set this option to normal.', 'fwdevp'); ?>">
			</td>
		</tr>
		<tr class="vr-options">
			<td>
				<label for="rotationY360DegreeVideo"><?php esc_html_e('360 video start rotation:', 'fwdevp'); ?></label>
			</td>
			<td>
				<input id="rotationY360DegreeVideo" type="text" class="text ui-widget-content ui-corner-all"><span>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('For 360 videos the start rotation in degrees, this can also be negative for example -90 will rotate the video on the Y axis / horizontally -90 degrees, by default is zero (0).', 'fwdevp'); ?>">
			</td>
		</tr>
		<tr class="vr-options">
			<td>
				<label for="startWhenPlayButtonClick360DegreeVideo"><?php esc_html_e('Start VR at play:', 'fwdevp'); ?></label>
			</td>
			<td>
				<select id="startWhenPlayButtonClick360DegreeVideo" class="ui-corner-all">
					<option value="yes"><?php esc_html_e('Yes', 'fwdevp'); ?></option>
					<option value="no"><?php esc_html_e('No', 'fwdevp'); ?></option>
				</select>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If you want to start VR when the video is starting to play set this option to yes otherwise leave it to no and the VR will start when the user is clicking the goggles button from the player control bar, if you want to use VR please set in your preset Show 360 degree VR button to yes otherwise lave set it to no.', 'fwdevp'); ?>"></span></input>
			</td>
		</tr>
		<tr>
			<td>
				<label for="fwdevp_is_private"><?php esc_html_e('Is private:', 'fwdevp'); ?></label>
			</td>
			<td>
				<select id="fwdevp_is_private" class="ui-corner-all">
					<option value="yes"><?php esc_html_e('Yes', 'fwdevp'); ?></option>
					<option value="no"><?php esc_html_e('No', 'fwdevp'); ?></option>
				</select>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Set this to yes to request a password to view the video, the password is set in the general settings in the presets.', 'fwdevp'); ?>">
			</td>
		</tr>
		<tr>
			<td>
				<label for="fwd_evpencript"><?php esc_html_e('Encrypt:', 'fwdevp'); ?></label>
			</td>
			<td>
				<select id="fwd_evpencript" class="ui-corner-all">
					<option value="yes"><?php esc_html_e('Yes', 'fwdevp'); ?></option>
					<option value="no"><?php esc_html_e('No', 'fwdevp'); ?></option>
				</select>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Set this feature to yes if you wish to encrypt the video paths this way it will not be possible to see / steal the videos location by viewing the page source.', 'fwdevp'); ?>">
			</td>
		</tr>
		<tr>
			<td>
				<label for="video_label"><?php esc_html_e('Video label:', 'fwdevp'); ?></label>
			</td>
			<td>
				<input id="video_label" type="text" class="text ui-widget-content ui-corner-all"><span>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The video / audio label that will appear in the video quality selector like: 720p, 1080p or whatever label you like. If you are using just a single video source this will not be displayed.', 'fwdevp'); ?>"></span></input>
			</td>
		</tr>
		<tr>
			<td>
				<label for="fwdevp_video_source"><?php esc_html_e('Video source:', 'fwdevp'); ?></label>
			</td>
			<td class="has-button">
				<input id="fwdevp_video_source" type="text" class="text ui-widget-content ui-corner-all"><span>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The video mp4 or audio mp3 path, VImeo video URL, Youtube video URL, HLS/m3u8 video URL, google drive video src path.', 'fwdevp'); ?>">
				<button id="fwdevp_upload_video_button"><?php esc_html_e('Add from media library', 'fwdevp'); ?></button>
			</td>
		</tr>
		<tr class="empty-after-button"></tr>
		<tr>
			<td>
				<label for="fwdevp_video_source2"><?php esc_html_e('Second video source:', 'fwdevp'); ?></label>
			</td>
			<td class="has-button">
				<input id="fwdevp_video_source2" type="text" class="text ui-widget-content ui-corner-all"><span>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If the first source fails and a second source is added EVP will try to play it. Please note the second source is not required also make sure that the second source has the same format (mp3, mp4, Youtube, Vimeo etc...) as the first source, for more info pelase read the documentation.', 'fwdevp'); ?>">
				<button id="fwdevp_upload_video_button2"><?php esc_html_e('Add from media library', 'fwdevp'); ?></button>
			</td>
		</tr>
		<tr class="empty-after-button"></tr>
	</table>

</div>


<!-- Subtitles dialog. -->
<div id="fwdevp_add-subtitle-dialog" title="<?php esc_html_e('Add new subtitle', 'fwdevp'); ?>">

	<p id="fwdevp_add-subtitle-tips"><?php esc_html_e('The label field is required.', 'fwdevp'); ?></p>
	<table class="fwdevp-dialog">
		<tr>
			<td>
				<label for="fwdevp_subtitle_label"><?php esc_html_e('Subtitle label:', 'fwdevp'); ?></label>
			</td>
			<td>
				<input id="fwdevp_subtitle_label" type="text" class="text ui-widget-content ui-corner-all">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The subtitle label that will appear in the subtitle quality selector like: 720p, 1080p or whatever label you like. If you are using just a single subtitle source this will not be displayed.', 'fwdevp'); ?>">
			</td>
		</tr>
		<tr>
			<td>
				<label for="subtitle_evpencript"><?php esc_html_e('Encrypt:', 'fwdevp'); ?></label>
			</td>
			<td>
				<select id="subtitle_evpencript" class="ui-corner-all">
					<option value="yes"><?php esc_html_e('Yes', 'fwdevp'); ?></option>
					<option value="no"><?php esc_html_e('No', 'fwdevp'); ?></option>
				</select>
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Set this feature to yes if you wish to encrypt the subtitle path this way it will not be possible to see / steal the subtitle source by viewing the page source.', 'fwdevp'); ?>">
			</td>
		</tr>
		<tr>
			<td>
				<label for="fwdevp_subtitle_source"><?php esc_html_e('Subtitle source:', 'fwdevp'); ?></label>
			</td>
			<td class="has-button">
				<input id="fwdevp_subtitle_source" type="text" class="text ui-widget-content ui-corner-all">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The subtitle .txt or .srt path.', 'fwdevp'); ?>">
				<button id="fwdevp_fwdevp_upload_subtitle_button"><?php esc_html_e('Add from media library', 'fwdevp'); ?></button>
			</td>
		</tr>
	</table>
</div>


<!-- Main shortcode. -->
<div id="fwdevp_shortcode_options_div" class="fwd-meta-box ui-widget fwdevp">

	<label for="fwdevp_presets_list"><?php esc_html_e('Select preset:', 'fwdevp'); ?></label>
	<select id="fwdevp_presets_list" class="ui-widget ui-corner-all"></select>

	<div class="fwdevp-vid-path-div">
		<label for="fwdevp_vid_path"><?php esc_html_e('Video source:', 'fwdevp'); ?></label>	
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<textarea onkeyup="fwdevp_adjustHeight(this);" id="fwdevp_vid_path" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp-add_video_button"><?php esc_html_e('Add video', 'fwdevp'); ?></button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('The video single or multiple source in object mode: {source:\'video_path\', label:\'video label\'}. Multiple videos obejcts can be added separated by \',\' : {source:\'video_path\', label:\'720p\'},{source:\'video_path2\', label:\'1080p\'}. If multiple sources are used the video quality selector will be visible.', 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>
	<br>
	
	<table class="fwdevp-start-at-video">
		<tr>
			<td>
				<label for="fwdevp_start_at_video"><?php esc_html_e('Start at video:', 'fwdevp'); ?></label>
				<input type="text" id="fwdevp_start_at_video" maxlength="1" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If more then one video source is used for the current video this can be used to set which video source will play by default, the counting starts from 1.', 'fwdevp'); ?>">
			</td>
			
			<td>
				<label class="fwdevp-playback-rate-speed" for="fwdevp_playback_rate_speed"><?php esc_html_e('Playback rate speed:', 'fwdevp'); ?></label>
				<select id="fwdevp_playback_rate_speed" class="ui-corner-all">
					<option value="0.25">0.25</option>
					<option value="0.5">0.5</option>
					<option value="1">1</option>
					<option value="1.25">1.25</option>
					<option value="1.5">1.5</option>
					<option value="2">2</option>
				</select>
			</td>
		</tr>
	</table>
	
	<table class="fwdevp-start-at-time">
		<tr>
			<td>
				<label for="fwdevp_start_at_time"><?php esc_html_e('Start at time:', 'fwdevp'); ?></label>
				<input type="text" id="fwdevp_start_at_time" maxlength="8" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Start playing the video at a specified time in format hours:minutes:seconds, for example 00:01:10. If you don\'t need this feature leave this blank.', 'fwdevp'); ?>">
			</td>
			<td>
				<label class="stop-at-time" for="fwdevp_stop_at_time"><?php esc_html_e('Stop at time:', 'fwdevp'); ?></label>
				<input type="text" id="fwdevp_stop_at_time" maxlength="8" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
				<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Stop playing the video at a specified time in format hours:minutes:seconds, for example 00:01:10. If you don\'t need this feature leave this blank.', 'fwdevp'); ?>">
			</td>
		</tr>
	</table>
	
	<div>
		<label for="fwdevp_vid_poster"><?php esc_html_e('Video poster (enter a URL or upload an image):', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<input id="fwdevp_vid_poster" type="text" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
					<button id="fwdevp_upload_poster_button"><?php esc_html_e('Add video poster from media library', 'fwdevp'); ?></button>
				</td>
				<td>
					<img src="" id="fwdevp_upload_poster">
				</td>
			</tr>
		</table>
	</div>

	<div class="fwdevp_subtitle">
		<label for="fwdevp_upload_subtitle"><?php esc_html_e('Subtitle .srt or .txt:', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<textarea id="fwdevp_subtitle_path" onkeyup="fwdevp_adjustHeight(this);" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp_add_subtitle_button"><?php esc_html_e('Add subtitle', 'fwdevp'); ?></button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="The subtitle single or multiple source in object mode: {source:'fwdevp_subtitle_path', label:'subtitle label'}. Multiple subtitle obejcts can be added separated by ',' : {source:'fwdevp_subtitle_path', label:'English'},{source:'fwdevp_subtitle_path2', label:'Romanian'}. If multiple sources are used the subtitle selector will be visible.">
				</td>
			</tr>
		</table>
	</div>
	
	<div class="fwdevp_start_at_subtitle_div">
		<label for="fwdevp_start_at_subtitle"><?php esc_html_e('Start at subtitle:', 'fwdevp'); ?></label>
		<input type="text" id="fwdevp_start_at_subtitle" maxlength="1" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
		<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('If more then one subtitle is used for the current video this can be used to set which subtitle is loaded by default, the counting starts from 1.', 'fwdevp'); ?>">
	</div>
	
	<div class="fwdevp-upload-popupad-edit">
		<label for="fwdevp_upload_popupad"><?php esc_html_e('Popup image or google adsense advertisement:', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<textarea id="fwdevp_popupad_path" onkeyup="fwdevp_adjustHeight(this);" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp_add_popupad_button"><?php esc_html_e('Add popup image or google adsense advertisement', 'fwdevp'); ?></button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e("The popupad single or multiple source in object mode: {source:'fwdevp_popupad_path', url:'url_to_open', target:'target', start_time:'hh:mm:ss', stop_time:'hh:mm:ss'}. Multiple popupad obejcts can be added separated by ',' : {source:'fwdevp_popupad_path'...},{source:'fwdevp_popupad_path2'...}. If multiple sources are used the popupad selector will be visible.", 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>

	<div class="fwdevp_vast_div">
		<label for="fwdevp_vast_path"><?php esc_html_e('VAST / VMAP / IMA advertisement:', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<textarea id="fwdevp_vast_path" onkeyup="fwdevp_adjustHeight(this);" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp_add_vast_button"><?php esc_html_e('Add VAST / VMAP / IMA', 'fwdevp'); ?></button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e("Currently EVP doesn't support VPAID.", 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>
	
	<div class="fwdevp-preroll-div">
		<label for="fwdevp_ads_fwdevp_vid_path"><?php esc_html_e('Advertising pre-roll,mid-roll,post-roll video (mp4 video, image, web page URL or Youtube video URL):', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<textarea id="fwdevp_video_ad_path" onkeyup="fwdevp_adjustHeight(this);"  class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp_add_video_ad_button"><?php esc_html_e('Add video advertisement', 'fwdevp'); ?></button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e("The pre-roll,mid-roll,post-roll video, image or web page URL(iframe) single or multiple source in object mode: {source:'video_or_image_path', url:'url_to_open' , target:'target', start_time:'hh:mm:ss', stop_time:'hh:mm:ss', fwdevp_time_to_hold_add:'seconds', fwdevp_add_duration:'hh:mm:ss'}. Multiple  obejcts can be added separated by ',' : {source:'video_or_image_path'...},{source:'video_or_image_path'...}. If multiple sources are used the popupad selector will be visible.", 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>
	
	<div class="fwdevp-advertisement-on-pause-div">
		<label for="pawp_source"><?php esc_html_e('Advertisement on pause window page source:', 'fwdevp'); ?></label>
		<div>
		<input type="text" id="pawp_source" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
		<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Add here the page URL of the page that you want to display in the advertisement window when the video is paused.', 'fwdevp'); ?>">
		</div>
	</div>
	
	<div id="fwdevp_videoad_link_type">
		<div>
		<label for="redirectURL"><?php esc_html_e('Redirect page when at video complete:', 'fwdevp'); ?></label>
		</div>
		<input type="text" id="redirectURL" class="text ui-widget-content ui-corner-all fwdevpInputFleds">
		<label class="redirectTarget" for="redirectTarget">Target:</label>
		<select id="redirectTarget" class="ui-corner-all">
			<option value="_self">_self</option>
			<option value="_blank">_blank</option>
			<option value="_parent">_parent</option>
		</select>
		<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e("This option allows to redirect or open a new page when the video has finished to play, if you want to use this just add the page URL that you want to redirect or open in a new page  in the 'Redirect page when at video complete' input, otherwise leave it blank.", 'fwdevp'); ?>">
	</div>

	<div class="fwdevp-cuepoints-div">
		<label for="fwdevp_video_cueppoint"><?php esc_html_e('Add cuepoint:', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<textarea id="fwdevp_video_cueppoint" onkeyup="fwdevp_adjustHeight(this);" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp_add_cuepoint_button">Add cuepoint</button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This featature allows to call javascript function at a specified time during video or audio playback.', 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>
	
	<div class="fwdevp-thumbnails-preview">
		<label for="fwdevp_thumbnails_preview"><?php esc_html_e('Thumbnails preview:', 'fwdevp'); ?></label>
		<table>
			<tr>
				<td class="fwdevp-first-td">
					<input type="text" id="fwdevp_thumbnails_preview_input"  class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea>
					<button id="fwdevp_thumbnails_preview_button"><?php esc_html_e('Add .vtt file', 'fwdevp'); ?></button>
				</td>
				<td class="fwdevp-second-td">
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('This feature allows adding a .vtt file to show thumbnails preview, for more info please read the documentation. If you want to use auto-generated thumbnails preview set this option to auto, please note that auto-generated thumbnails preview works only with self-hosted or external hosted mp4/video, HLS/m3u8, Google Drive, Dropbox, Amazon S3, and more, where .vtt thumbnail preview support all video and audio formats.', 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>

	<div class="fwdevp-shortcode">
		<label for="shortcode"><?php esc_html_e('Shortcode:', 'fwdevp'); ?></label>
		<table>
			<tr class="fwdevp-first-td">
				<td>
					<span><textarea  readonly id="fwdevpShortCode" class="text ui-widget-content ui-corner-all fwdevpInputFleds"></textarea></span>
				</td>
				<td>
					<img class="fwdevp-img-tooltip" src="<?php echo esc_url($tootlTipImgSrc); ?>" title="<?php esc_html_e('Copy and paste the shortcode from here.', 'fwdevp'); ?>">
				</td>
			</tr>
		</table>
	</div>
	<div id="fwdevp_div" class="fwd-updated"><p id="fwdevp_msg"></p></div>
</div>