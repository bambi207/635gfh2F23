<?php
/*
Plugin Name: Easy Video Player
Plugin URI: http://codecanyon.net/item/easy-video-player-wordpress-plugin/8537670
Description: This is the WordPress plugin with a CMS menu for the installation and configuration of the Easy Video Player.
Author: FWD
Version: 9.2
Author URI: http://webdesign-flash.ro/
*/

include_once "php/FWDEVP.php";
include_once "php/FWDEVPData.php";
define('FWDEVP_TEXT_DOMAIN',  wp_get_theme()->get('TextDomain'));


function fwdevp_check_if_admin(){	
	$roles = wp_get_current_user()->roles;
	$role = "administrator";
	 
	return in_array($role, $roles);
}

function fwdevp_admin_init(){	
	if (fwdevp_check_if_admin()){
		$role = get_role("administrator");
		$role->add_cap(FWDEVP::CAPABILITY);
	}
}

function fwdevp_init_plugin(){	
	$evp = new FWDEVP();
	$evp->init();
}

add_action("init", "fwdevp_init_plugin", 0);
add_action("admin_init", "fwdevp_admin_init");
add_filter("plugin_action_links_" . plugin_basename(__FILE__), array("FWDEVP", "fwdevp_set_action_links"));
?>